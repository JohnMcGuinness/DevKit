module sproutparser.advanced {
	requires io.vavr;
	requires sproutparser.common;
}