package com.github.sproutparser.advanced;

import com.github.sproutparser.common.DeadEnd;
import com.github.sproutparser.common.Located;
import com.github.sproutparser.common.Result;
import com.github.sproutparser.common.Token;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static com.github.sproutparser.advanced.AdvancedParser.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class AdvancedParserTest {

	@Test
	public void succeedTest() {

		int expected = 3;
		final Result<List<DeadEnd<Void, Void>>, Integer> result
			= run(
				succeed(expected),
				"abc"
			);

		assertOk(expected, result);
	}

	@Test
	public void problemTest() {

		final String msg = "There was an error";
		final Result<List<DeadEnd<Void, String>>, Integer> result
			= run(
				problem(msg),
				"abc"
			);

		assertError(new DeadEnd<>(1, 1, msg, List.of()), result);
	}

	@Test
	public void mapTest() {

		final String expected = "3";

		final Result<List<DeadEnd<Void, String>>, Integer> result
			= run(
				map(
					Integer::valueOf,
					succeed(expected)
				),
				""
			);

		assertOk(3, result);
	}

//    @Test
//    public void keepTest() {
//
////        record Demo2(String value1, String value2) {}
////        Parser<Void, Void, BiFunction<String, String,Demo2>> Demo2 = succeed(Demo2::new);
//
//        record Demo1(String value) { }
//
//        Parser<Void, Void, Integer> p = keep(succeed(Integer::valueOf), succeed("1"));
//
//        Parser<Void, Void, Function<String, Demo1>> Demo1 = succeed(Demo1::new);
//
//
//        Parser<Void, Void, Demo1> p1 = keep(Demo1, succeed("1"));
//
////        Parser<Void, Void, Demo2> p2 = keep(Demo2, succeed("1"));
//
//        /*
//            keep(
//                succeed(Demo::new),
//                succeed("1")
//            );
//        */
//        final Either<List<DeadEnd<Void, Void>>, Integer> result = Parser.run(p, "");
//
//        assertTrue(result.isRight());
//        assertEquals(1, result.get());
//    }

	@Test
	public void andThenTest() {

		final Result<List<DeadEnd<Void, String>>, Integer> result
			= run(
				andThen(
					s -> succeed(s + 5),
					integer("expecting_message", "invalid_message")
				),
				"2"
			);

		assertOk(7, result);
	}

	@Test
	public void lazyTest() {

		final var result
			= run(
				lazy(() -> integer("expecting_message", "invalid_message")),
				"12"
			);

		assertOk(12, result);
	}

	@Test
	public void intTest_Success_IntOnly() {

		final int intNumber = 15;

		final Result<List<DeadEnd<Void, String>>, Integer> result
			= run(
				integer("expecting an int", "invalid int"),
				String.valueOf(intNumber)
			);

		assertOk(intNumber, result);
	}

	@Test
	public void intTest_Success_FollowedByAlpha() {

		final int intNumber = 15;

		final Result<List<DeadEnd<Void, String>>, Integer> result
			= run(
				integer("expecting an int", "invalid int"),
				intNumber + "ab"
			);

		assertOk(intNumber, result);
	}

	@Test
	public void integerTest_Invalid_Float() {

		final double doubleNumber = 15.7;

		final Result<List<DeadEnd<Void, String>>, Integer> result
			= run(
				integer("expecting an int", "invalid int"),
				String.valueOf(doubleNumber)
			);

		assertError(new DeadEnd<>(1, 1, "invalid int", List.of()), result);
	}

//	@Test
//	public void floatTest_Success() {
//
//		final float doubleNumber = 15.7f;
//
//		final Either<List<DeadEnd<Void, String>>, Float> result
//			= AdvancedParser.run(AdvancedParser.floatingPoint("expecting an float", "invalid float"), String.valueOf(doubleNumber));
//
//		assertTrue(result.isRight());
//		assertEquals(doubleNumber, result.get());
//	}

//	@Test
//	public void floatTest_Success_AsInteger() {
//
//		final int doubleNumber = 15;
//
//		final Either<List<DeadEnd<Void, String>>, Float> result
//			= AdvancedParser.run(AdvancedParser.floatingPoint("expecting an float", "invalid float"), String.valueOf(doubleNumber));
//
//		assertTrue(result.isRight());
//		assertEquals(doubleNumber, result.get());
//	}

	@Test
	public void spacesTest() {

		assertOk(null, run(spaces(), "\n"));
		assertOk(null, run(spaces(), "\r"));
		assertOk(null, run(spaces(), " "));
		assertOk(null, run(spaces(), "c"));
	}

	@Test
	public void tokenTest() {

		final AdvancedParser<Void, String, Void> token = token(new Token<>("let", "expecting let"));

		final Result<List<DeadEnd<Void, String>>, Void> result1
			= run(
				token,
				"let"
			);

		assertOk(null, result1);

		final Result<List<DeadEnd<Void, String>>, Void> result2
			= run(
				token,
				"abc"
			);

		assertError(new DeadEnd<>(1, 1, "expecting let", List.of()), result2);
	}

	@Test
	public void map2Test()  {

		record MyObject(int i, String s) { }

		final int expectedInteger = 2;
		final String expectedString = "Joe";
		final MyObject expected = new MyObject(expectedInteger, expectedString);

		final Result<List<DeadEnd<Void, String>>, MyObject> result
			= run(
				map2(
					MyObject::new,
					integer("expecting_message", "invalid_message"),
					succeed(expectedString)
				),
				String.valueOf(expectedInteger)
			);

		assertOk(expected, result);
	}
//	@Test
//	public void symbolTest() {
//
//		final AdvancedParser<Void, String, Void> symbol = AdvancedParser.symbol(new Token<>("let", "expecting let"));
//
//		assertTrue(AdvancedParser.run(symbol, "let").isRight());
//
//		final Either<List<DeadEnd<Void, String>>, Void> result = AdvancedParser.run(symbol, "abc");
//
//		assertTrue(result.isLeft());
//		assertEquals(1, result.getLeft().size());
//
//		final DeadEnd<Void, String> deadEnd = result.getLeft().get(0);
//
//		assertEquals("expecting let", deadEnd.problem());
//	}

	@Test
	public void endTest() {

		final AdvancedParser<Void, String, Void> end = end("expecting end");

		final Result<List<DeadEnd<Void, String>>, Void> result1
			= run(
				end,
				""
			);

		assertOk(null, result1);

		final Result<List<DeadEnd<Void, String>>, Void> result2
			= run(
				end,
				"abc"
			);

		assertError(new DeadEnd<>(1, 1, "expecting end", List.of()), result2);
	}

	@Test
	public void inContextTest() {

		final Result<List<DeadEnd<String, String>>, String> result
			= run(
				inContext(
					"a demo context",
					problem("this is a problem")
				),
				""
			);

		assertError(
			new DeadEnd<>(1, 1, "this is a problem", List.of(new Located<>(1, 1, "a demo context"))),
			result
		);
	}

	@Test
	public void keywordTest() {

		final AdvancedParser<Void, String, Void> keyword
			= keyword(
				new Token<>("let", "expected let")
			);

		final Result<List<DeadEnd<Void, String>>, Void> result1
			= run(
				keyword,
				"let"
			);

		assertOk(null, result1);

		final Result<List<DeadEnd<Void, String>>, Void> result2
			= run(
				keyword,
				"xyz"
			);

		assertError(new DeadEnd<>(1, 1, "expected let", List.of()), result2);
	}

	@Test
	public void variableTest() {

		final AdvancedParser<Void, String, String> variable
			= variable(
				Character::isJavaIdentifierStart,
				Character::isJavaIdentifierPart,
				Set.of("let"),
				"an expecting message"
			);

		final Result<List<DeadEnd<Void, String>>, String> result
			= run(
				variable,
				"letter "
			);

		assertOk("letter", result);
	}

	@Test
	public void lineCommentTest() {

		final AdvancedParser<Void, String, String> variable
			= variable(
			Character::isLowerCase,
			Character::isLetter,
			Set.of("let"),
			"an expecting message"
		);

		final AdvancedParser<Void, String, String> parser = andThen(n -> variable, lineComment(new Token<>("#", "an expecting message")));

		final Result<List<DeadEnd<Void, String>>, String> result
			= run(
				andThen(
					n -> variable,
					lineComment(new Token<>("#", "an expecting message"))
				),
				"""
        		# A line comment
		        myName
            	"""
			);

		assertOk("myName", result);
	}

	@Test
	public void mapChompedStringTest() {

		record SourceAndValue<T>(String source, T value) { }

		final Result<List<DeadEnd<Void, String>>, SourceAndValue<Integer>> result
			= run(
				mapChompedString(
					SourceAndValue::new,
					integer("expecting message", "invalid message")
				),
				"123"
			);

		assertOk(new SourceAndValue<>("123", 123), result);
	}

	public static <C, X, T> void assertError(final DeadEnd<C, X> expected, final Result<List<DeadEnd<C, X>>, T> actual) {
		assertError(expected, actual, 0);
	}

	public static <C, X, T> void assertError(final DeadEnd<C, X> expected, final Result<List<DeadEnd<C, X>>, T> actual, int index) {
		assertTrue(actual.isErr());
		assertNotNull(actual.error());
		assertEquals(expected, actual.error().get(index));
	}

	public static <X, T> void assertOk(final T expected, final Result<X, T> actual) {
		assertTrue(actual.isOk());
		assertEquals(expected, actual.value());
	}
}
