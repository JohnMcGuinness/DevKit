package com.github.sproutparser.common;

import com.github.sproutparser.common.ParserImpl;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class FindSubStringTest {

	@Test
	@DisplayName("findSubString - at start of longer string")
	public void findSubString1() {

		final String shorter = "abc";
		final String longer = "abcd";

		final int[] result = ParserImpl.findSubString(shorter, 0, 1,1, longer);

		assertArrayEquals(new int[]{3, 1, 4}, result);
	}

	@Test
	@DisplayName("findSubString - contained in longer string, occurs once")
	public void findSubString2() {

		final String shorter = "bc";
		final String longer = "abcd";

		final int[] result = ParserImpl.findSubString(shorter, 0, 1,1, longer);

		assertArrayEquals(new int[]{3, 1, 4}, result);
	}

	@Test
	@DisplayName("findSubString - contained in longer string, occurs more than once")
	public void findSubString3() {

		final String shorter = "bc";
		final String longer = "abcdabcd";

		final int[] result = ParserImpl.findSubString(shorter, 4, 1,5, longer);

		assertArrayEquals(new int[]{7, 1, 8}, result);
	}

	@Test
	@DisplayName("findSubString - at end of longer string")
	public void findSubString4() {

		final String shorter = "bcd";
		final String longer = "abcd";

		final int[] result = ParserImpl.findSubString(shorter, 0, 1,1, longer);

		assertArrayEquals(new int[]{4, 1, 5}, result);
	}

	@Test
	@DisplayName("findSubString - not present in longer string")
	public void findSubString5() {

		final String shorter = "xyz";
		final String longer = "abcd";

		final int[] result = ParserImpl.findSubString(shorter, 0, 1,1, longer);

		assertArrayEquals(new int[]{4, 1, 5}, result);
	}

	@Test
	@DisplayName("findSubString - is present in longer string and wraps around lines")
	public void findSubString6() {

		final String shorter = """
			d
			ef""";

		final String longer = """
            abcd
            efgh
            """;

		final int[] result = ParserImpl.findSubString(shorter, 3, 1,4, longer);

		assertArrayEquals(new int[]{7, 2, 3}, result);
	}
}
