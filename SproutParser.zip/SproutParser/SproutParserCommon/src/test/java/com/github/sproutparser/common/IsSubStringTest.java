package com.github.sproutparser.common;

import com.github.sproutparser.common.ParserImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

public class IsSubStringTest {

    @Test
    @DisplayName("isSubString - substring equals full string")
    public void isSubStringTest1() {
        assertArrayEquals(new int[]{2, 1, 3}, ParserImpl.isSubString("ab", 0, 1, 1, "ab"));
    }

    @Test
    @DisplayName("isSubString - substring exists within in longer string")
    public void isSubStringTest2() {
        assertArrayEquals(new int[]{3,1,4}, ParserImpl.isSubString("bc", 1, 1, 2, "abcd"));
    }

    @Test
    @DisplayName("isSubString - substring exists at end of longer string")
    public void isSubStringTest3() {
        assertArrayEquals(new int[]{4,1,5}, ParserImpl.isSubString("d", 3, 1, 4, "abcd"));
    }

    @Test
    @DisplayName("isSubString - substring exists at start of longer string")
    public void isSubStringTest4() {
        assertArrayEquals(new int[]{1,1,2}, ParserImpl.isSubString("a", 0, 1, 1, "abcd"));
    }

    @Test
    @DisplayName("isSubString - substring containing multibyte character exists within longer string")
    public void isSubStringTest5() {
        assertArrayEquals(new int[]{5,1,6}, ParserImpl.isSubString("b☃️d", 1, 1, 2, "ab☃️de"));
    }

    @Test
    @DisplayName("isSubString - substring exists within multi line longer string")
    public void isSubStringTest6() {

        final String multiline = """
            abc
            cde
            fghi
            """;

        assertArrayEquals(new int[]{11,3,4}, ParserImpl.isSubString("gh", 9, 3, 2, multiline));
    }

    @Test
    @DisplayName("isSubString - substring does not exists within longer string")
    public void isSubStringTest7() {
        assertArrayEquals(new int[]{-1, 1, 1}, ParserImpl.isSubString("x", 0, 1, 1, "abc"));
    }
}
