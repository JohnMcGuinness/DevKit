package com.github.sproutparser.common;

import com.github.sproutparser.common.ParserImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class IsSubCharTest {

    @Test
    @DisplayName("isSubChar - matching a multi-byte character")
    public void isSubCharTest1() {
        assertEquals(2, ParserImpl.isSubChar(codePoint -> codePoint.equals("🎱".codePointAt(0)), 0, "🎱"));
    }

    @Test
    @DisplayName("isSubChar - matching a single byte character")
    public void isSubCharTest2() {
        assertEquals(1, ParserImpl.isSubChar(codePoint -> 'a' == codePoint, 0, "abc"));
    }

    @Test
    @DisplayName("isSubChar - not matching")
    public void isSubCharTest3() {
        assertEquals(-1, ParserImpl.isSubChar(codePoint -> 'x' == codePoint, 0, "a"));
    }

    @Test
    @DisplayName("isSubChar - matching a new line character")
    public void isSubCharTest4() {
        assertEquals(-2, ParserImpl.isSubChar(codePoint -> '\n' == codePoint, 0, "\n"));
    }
}
