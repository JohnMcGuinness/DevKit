module sproutparser.common {
	requires io.vavr;
	exports com.github.sproutparser.common to sproutparser.advanced, sproutparser.basic;
}
