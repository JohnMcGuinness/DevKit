package com.github.sproutparser.common.internal;

public record Empty<C, X>() implements Bag<C, X> {
}
