package com.github.simpleparser;

import com.github.sproutparser.common.Result;
import com.github.sproutparser.DeadEnd;
import com.github.sproutparser.ExpectingInt;
import com.github.sproutparser.Parser;
import com.github.sproutparser.Problem;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import static com.github.sproutparser.Parser.*;

public class BasicParserTest {

	@Test
	public void succeedTest() {

		final Result<List<DeadEnd>, Float> result
			= run(
				succeed(1f),
				"abc"
			);

		assertTrue(result.isOk());
		assertEquals(1f, result.value());
	}

	@Test
	public void problemTest() {

		final Problem problem = new ExpectingInt();

		final Result<List<DeadEnd>, Integer> result
			= run(
				problem(problem),
				"abc"
			);

		assertTrue(result.isErr());

		final List<DeadEnd> deadEnds = result.error();

		assertNotNull(deadEnds);
		assertEquals(1, deadEnds.size());

		final DeadEnd deadend = deadEnds.get(0);

		assertEquals(1, deadend.row());
		assertEquals(1, deadend.column());
		assertEquals(problem, deadend.problem());
	}

	@Test
	public void mapTest() {

		final int expected = 3;
		final Result<List<DeadEnd>, Integer> result
			= run(
				map(
					Integer::valueOf,
					succeed(expected)
				),
				"abc"
			);

		assertTrue(result.isOk());
		assertEquals(expected, result.value());
	}

	@Test
	public void map2Test()  {

		record MyObject(int i, String s) { }

		final int expectedInteger = 2;
		final String expectedString = "Joe";
		final MyObject expected = new MyObject(expectedInteger, expectedString);

		final Result<List<DeadEnd>, MyObject> result
				= run(
				map2(
					MyObject::new,
					integer(),
					succeed(expectedString)
				),
				String.valueOf(expectedInteger)
		);

		assertTrue(result.isOk());
		assertEquals(expected, result.value());
	}

	@Test
	public void endTest() {

		final Parser<Void> end = end();

		final Result<List<DeadEnd>, Void> result1
			= run(
				end,
				""
			);

		assertTrue(result1.isOk());
		assertNull(result1.value());

		final Result<List<DeadEnd>, Void> result2
			= run(
				end,
				"abc"
			);

		assertTrue(result2.isErr());
		assertEquals(1, result2.error().size());

		final DeadEnd deadEnd = result2.error().get(0);
		assertEquals(Problem.EXPECTING_END, deadEnd.problem());
	}

	@Test
	public void andThenTest() {

		final Result<List<DeadEnd>, Integer> result
			= run(
				andThen(
					i -> Parser.succeed(i + 2),
					integer()
				),
				"12"
			);

		assertTrue(result.isOk());
		assertEquals(14, result.value());
	}

	@Test
	public void lazyTest() {

		final int expected = 12;
		final Result<List<DeadEnd>, Integer> result
			= run(
				lazy(Parser::integer),
				String.valueOf(expected)
			);

		assertTrue(result.isOk());
		assertEquals(expected, result.value());
	}

	@Test
	public void tokenTest() {

		final Result<List<DeadEnd>, Void> result
			= run(
				token("let"),
				"letter"
			);

		assertTrue(result.isOk());
		assertNull(result.value());
	}

	@Test
	public void variableTest() {

		final Parser<String> variable
			= variable(
				Character::isJavaIdentifierStart,
				Character::isJavaIdentifierPart,
				Set.of("let")
			);

		final Result<List<DeadEnd>, String> result
			= run(
				variable,
				"""
                letter = b; 
                """
			);

		assertTrue(result.isOk());
		assertEquals("letter", result.value());
	}

	@Test
	@DisplayName("spaces - matches a new line character")
	public void spacesTest1() {
		assertTrue(run(spaces(), "\n").isOk());
	}

	@Test
	@DisplayName("spaces - matches a carriage return character")
	public void spacesTest2() {
		assertTrue(run(spaces(), "\r").isOk());
	}

	@Test
	@DisplayName("spaces - matches a space")
	public void spacesTest3() {
		assertTrue(run(spaces(), " ").isOk());
	}

	@Test
	@DisplayName("spaces - matches a non space")
	public void spacesTest4() {
		assertTrue(run(spaces(), "x").isOk());
	}
}
