package com.github.simpleparser;

import com.github.sproutparser.DeadEnd;
import com.github.sproutparser.Parser;
import com.github.sproutparser.common.Result;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.List;
import java.util.Optional;

import static com.github.sproutparser.Parser.number;
import static com.github.sproutparser.Parser.run;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class BasicParserNumberTest {

	@Test
	public void integerNumberTest() {

		Parser<Integer> integer = number(
			Optional.of(Integer::valueOf),
			Optional.empty(),
			Optional.empty(),
			Optional.empty(),
			Optional.empty()
		);

		Result<List<DeadEnd>, Integer> result =  run(integer, "23");

		assertTrue(result.isOk());
		assertEquals(Integer.valueOf(23), result.value());
	}

	@Test
	public void hexTest() {

		Parser<Integer> integer = number(
			Optional.empty(),
			Optional.of(Integer::valueOf),
			Optional.empty(),
			Optional.empty(),
			Optional.empty()
		);

		Result<List<DeadEnd>, Integer> result =  run(integer, "0x23");

		assertTrue(result.isOk());
		assertEquals(Integer.valueOf(35), result.value());
	}

	@Test
	public void octalTest() {

		Parser<Integer> integer = number(
			Optional.empty(),
			Optional.empty(),
			Optional.of(Integer::valueOf),
			Optional.empty(),
			Optional.empty()
		);

		Result<List<DeadEnd>, Integer> result =  run(integer, "0o23");

		assertTrue(result.isOk());
		assertEquals(Integer.valueOf(19), result.value());
	}

	@Test
	public void binaryTest() {

		Parser<Integer> integer = number(
			Optional.empty(),
			Optional.empty(),
			Optional.empty(),
			Optional.of(Integer::valueOf),
			Optional.empty()
		);

		Result<List<DeadEnd>, Integer> result =  run(integer, "0b1101");

		assertTrue(result.isOk());
		assertEquals(Integer.valueOf(13), result.value());
	}

	@Test
	@Disabled("The float parser needs a lot of work to get it working with precision, scale etc.")
	public void floatTest() {

		final Parser<BigDecimal> number = number(
			Optional.empty(),
			Optional.empty(),
			Optional.empty(),
			Optional.empty(),
			Optional.of(s -> new BigDecimal(s, MathContext.DECIMAL32))
		);

		Result<List<DeadEnd>, BigDecimal> result =  run(number, "1.24");

		assertTrue(result.isOk());
		assertEquals(new BigDecimal("1.24", MathContext.DECIMAL32), result.value());
	}

	@Test
	public void integerTest() {

//		final Parser<Integer> integer = integer();
	}
}
