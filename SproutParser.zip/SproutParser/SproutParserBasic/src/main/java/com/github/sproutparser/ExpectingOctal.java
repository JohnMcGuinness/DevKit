package com.github.sproutparser;

public record ExpectingOctal() implements Problem { }
