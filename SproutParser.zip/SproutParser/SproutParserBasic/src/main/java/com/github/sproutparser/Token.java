package com.github.sproutparser;

public class Token {
}
