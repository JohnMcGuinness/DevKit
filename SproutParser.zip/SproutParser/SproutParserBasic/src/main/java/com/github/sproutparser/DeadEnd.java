package com.github.sproutparser;

public record DeadEnd(int row, int column, Problem problem) { }
