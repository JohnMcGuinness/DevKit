package com.github.sproutparser;

public record ExpectingNumber() implements Problem { }

