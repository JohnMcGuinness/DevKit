package com.github.sproutparser;

public record ExpectingHex() implements Problem { }
