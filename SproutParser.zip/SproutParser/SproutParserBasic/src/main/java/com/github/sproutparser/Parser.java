package com.github.sproutparser;

import com.github.sproutparser.common.AbstractParser;
import com.github.sproutparser.common.Err;
import com.github.sproutparser.common.Ok;
import com.github.sproutparser.common.PStep;
import com.github.sproutparser.common.Result;
import com.github.sproutparser.common.State;
import com.github.sproutparser.common.ParserImpl;
import com.github.sproutparser.common.Token;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public final class Parser<T> extends AbstractParser<Void, Problem, T> {

	private Parser(final Function<State<Void>, PStep<Void, Problem, T>> parse) {
		super(parse);
	}

	public static <T> Result<List<DeadEnd>, T> run(final Parser<T> parser, String source) {

		final Result<List<com.github.sproutparser.common.DeadEnd<Void, Problem>>, T> result = ParserImpl.run(parser, source);

		if (result instanceof Ok<?, T> right) {
			return new Ok<>(right.value());
		} else {
			final List<com.github.sproutparser.common.DeadEnd<Void, Problem>> problems = result.error();

			final List<DeadEnd> deadEnds = problems
				.stream()
				.map(Parser::problemToDeadEnd)
				.collect(Collectors.toList());

			return new Err<>(deadEnds);
		}
	}

	private static DeadEnd problemToDeadEnd(final com.github.sproutparser.common.DeadEnd<Void, Problem> problem) {
		return new DeadEnd(problem.row(), problem.column(), problem.problem());
	}

	public static <T> Parser<T> succeed(final T value) {
		return  new Parser<>(ParserImpl.succeedF(value));
	}

	public static <T> Parser<T> problem(final Problem problem) {
		return new Parser<>(ParserImpl.problemF(problem));
	}

	public static <T1, T2> Parser<T1> ignore(final Parser<T1> keep, final Parser<T2> ignore) {
		return new Parser<>(ParserImpl.ignoreF(keep, ignore));
	}

//	public static Parser<Void> lineComment(final Token start) {
//		return ignore(token(start), chompUntilEndOr("\n"));
//	}

	public static <T, R> Parser<R> map(final Function<T, R> f, final Parser<T> parser) {
		return new Parser<>(ParserImpl.mapF(f, parser));
	}

	public static <T1, T2, R> Parser<R> map2(final BiFunction<T1, T2, R> f, final Parser<T1> parserA, final Parser<T2> parserB) {
		return new Parser<>(ParserImpl.map2F(f, parserA, parserB));
	}

	public static <T, R> Parser<R> andThen(final Function<T, Parser<R>> callback, final Parser<T> parser) {
		return new Parser<>(ParserImpl.andThenF(callback, parser));
	}

	public static <T> Parser<T> lazy(final Supplier<Parser<T>> thunk) {
		return new Parser<>(ParserImpl.lazyF(thunk));
	}

	public static Parser<Void> token(final String token) {
		return new Parser<>(ParserImpl.tokenF(new Token<>(token, new Expecting(token))));
	}

	/**
	 * Parse zero or more new line, carriage return or space characters.
	 *
	 * If you need something different (like tabs) just define an alternative with the necessary tweaks! Check out
	 * {@link lineComment} and {@link multiComment} for more complex situations.
	 *
	 * @return a Parser that parses spaces.
	 */
	public static Parser<Void> spaces() {
		return new Parser<>(ParserImpl.spacesF());
	}

	public static Parser<Void> end() {
		return new Parser<>(ParserImpl.endF(Problem.EXPECTING_END));
	}

	public static <T> Parser<T> number(
		final Optional<Function<Integer, T>> integer,
		final Optional<Function<Integer, T>> hexadecimal,
		final Optional<Function<Integer, T>> octal,
		final Optional<Function<Integer, T>> binary,
		final Optional<Function<Float, T>> float_)
	{

		return new Parser<>(ParserImpl.numberF(
			Result.fromOptional(Problem.EXPECTING_INT, integer),
			Result.fromOptional(Problem.EXPECTING_HEX, hexadecimal),
			Result.fromOptional(Problem.EXPECTING_OCTAL, octal),
			Result.fromOptional(Problem.EXPECTING_BINARY, binary),
			Result.fromOptional(Problem.EXPECTING_FLOAT, float_),
			Problem.EXPECTING_NUMBER,
			Problem.EXPECTING_NUMBER)
		);
	}

	public static Parser<Integer> integer() {
		return number(
			Optional.of(Function.identity()),
			Optional.empty(),
			Optional.empty(),
			Optional.empty(),
			Optional.empty()
		);
	}

	public static Parser<String> variable(
		final Predicate<Integer> start,
	    final Predicate<Integer> inner,
	    final Set<String> reserved
	) {
		return new Parser<>(ParserImpl.variableF(start, inner, reserved, Problem.EXPECTING_VARIABLE));
	}

	private static Token<Problem> toToken(final String str) {
		return new Token<>(str, Problem.expecting(str));
	}
}
