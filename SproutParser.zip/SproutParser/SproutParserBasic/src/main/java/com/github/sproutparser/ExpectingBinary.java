package com.github.sproutparser;

public record ExpectingBinary() implements Problem { }
