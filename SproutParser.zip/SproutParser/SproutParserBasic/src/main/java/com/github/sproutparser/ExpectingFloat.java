package com.github.sproutparser;

public record ExpectingFloat() implements Problem { }
