package com.github.sproutparser;

public record Expecting(String message) implements Problem {
}
