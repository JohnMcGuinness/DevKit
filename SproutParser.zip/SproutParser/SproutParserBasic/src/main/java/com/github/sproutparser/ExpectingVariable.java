package com.github.sproutparser;

public record ExpectingVariable() implements Problem {
}
