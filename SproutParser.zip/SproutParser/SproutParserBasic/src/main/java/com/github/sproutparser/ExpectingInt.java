package com.github.sproutparser;

public record ExpectingInt() implements Problem { }
