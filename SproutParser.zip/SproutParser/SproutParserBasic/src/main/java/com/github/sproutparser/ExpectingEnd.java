package com.github.sproutparser;

public record ExpectingEnd() implements Problem { }
