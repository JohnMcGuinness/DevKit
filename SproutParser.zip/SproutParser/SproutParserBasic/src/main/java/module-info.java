module sproutparser.basic {
	requires sproutparser.common;
	requires io.vavr;
	exports com.github.sproutparser;
}
