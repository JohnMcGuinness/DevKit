module simpleparser.advanced {
	requires io.vavr;
	requires simpleparser.common;
}