package com.github.simpleparser.advanced;

public record Token<X>(String string, X expecting) { }
