package com.github.simpleparser.advanced;

import com.github.simpleparser.common.DeadEnd;
import com.github.simpleparser.common.Result;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static com.github.simpleparser.advanced.AdvancedParser.run;
import static com.github.simpleparser.advanced.AdvancedParser.variable;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class AdvancedParserVariableTest {

	private AdvancedParser<Void, String, String> parser;

	@BeforeEach
	public void setup() {
		parser = variable(
				Character::isJavaIdentifierStart,
				Character::isJavaIdentifierPart,
				Set.of("let"),
				"an expecting message"
		);
	}

	@Test
	public void variableTest_Ok() {

		final Result<List<DeadEnd<Void, String>>, String> result
			= run(
				parser,
				"letter "
			);

		assertTrue(result.isOk());
		assertEquals("letter", result.value());
	}

	@Test
	public void variableTest_Err_StartPredicateFails() {

		final String problem = "an expecting message";

		final Result<List<DeadEnd<Void, String>>, String> result
			= run(
				parser,
				"3letter "
			);

		assertTrue(result.isErr());
		assertEquals(1, result.error().size());
		assertEquals(new DeadEnd<>(1, 1, problem, List.of()), result.error().get(0));
	}

	@Test
	public void variableTest_Err_Reserved() {

		final String problem = "an expecting message";

		final Result<List<DeadEnd<Void, String>>, String> result
			= run(
				parser,
				"let "
			);

		assertTrue(result.isErr());
		assertEquals(1, result.error().size());
		assertEquals(new DeadEnd<>(1, 1, problem, List.of()), result.error().get(0));
	}

	@Test
	public void variableTest_Ok_InnerPredicateFails() {

		final Result<List<DeadEnd<Void, String>>, String> result
			= run(
				parser,
				"lett@er "
			);

		assertTrue(result.isOk());
		assertEquals("lett", result.value());
	}
}
