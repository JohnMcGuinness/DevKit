package com.github.simpleparser.advanced;

import com.github.simpleparser.common.DeadEnd;
import io.vavr.control.Either;
import org.junit.jupiter.api.Test;

import java.util.List;

import static com.github.simpleparser.advanced.AdvancedParser.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class AdvancedParserTest {

	@Test
	public void succeedTest() {

		int expected = 3;
		final Either<List<DeadEnd<Void, Void>>, Integer> result = run(succeed(expected), "abc");

		assertTrue(result.isRight());
		assertEquals(expected, result.get());
	}

	@Test
	public void problemTest() {

		final String msg = "There was an error";
		final Either<List<DeadEnd<Void, String>>, Integer> result = AdvancedParser.run(AdvancedParser.problem(msg), "abc");

		assertTrue(result.isLeft());

		final List<DeadEnd<Void, String>> deadEnds = result.getLeft();

		assertNotNull(deadEnds);
		assertEquals(1, deadEnds.size());

		final DeadEnd<Void, String> deadend = deadEnds.get(0);

		assertEquals(1, deadend.row());
		assertEquals(1, deadend.column());
		assertEquals(msg, deadend.problem());
		assertTrue(deadend.contextStack().isEmpty());
	}

	@Test
	public void mapTest() {

		final String expected = "3";
		final AdvancedParser<Void, String, Integer> m = AdvancedParser.map(Integer::valueOf, AdvancedParser.succeed(expected));

		final Either<List<DeadEnd<Void, String>>, Integer> result = AdvancedParser.run(m, "");
		// Parser.succeed(expected).map(Integer::valueOf).run("");

		assertTrue(result.isRight());

		assertEquals(3, result.get());
	}

//    @Test
//    public void keepTest() {
//
////        record Demo2(String value1, String value2) {}
////        Parser<Void, Void, BiFunction<String, String,Demo2>> Demo2 = succeed(Demo2::new);
//
//        record Demo1(String value) { }
//
//        Parser<Void, Void, Integer> p = keep(succeed(Integer::valueOf), succeed("1"));
//
//        Parser<Void, Void, Function<String, Demo1>> Demo1 = succeed(Demo1::new);
//
//
//        Parser<Void, Void, Demo1> p1 = keep(Demo1, succeed("1"));
//
////        Parser<Void, Void, Demo2> p2 = keep(Demo2, succeed("1"));
//
//        /*
//            keep(
//                succeed(Demo::new),
//                succeed("1")
//            );
//        */
//        final Either<List<DeadEnd<Void, Void>>, Integer> result = Parser.run(p, "");
//
//        assertTrue(result.isRight());
//        assertEquals(1, result.get());
//    }

	@Test
	public void andThenTest() {

		final Either<List<DeadEnd<Void, String>>, Integer> result
			= run(
				andThen(
					s -> succeed(100),
					succeed("1")),
					"2"
			);

		assertTrue(result.isRight());
		assertEquals(100, result.get());
	}

//	@Test
//	public void lazyTest() {
//
//		AdvancedParser<Void, String, Integer> p = AdvancedParser.lazy(() -> AdvancedParser.integer("expecting_message", "invalid_message"));
//
//		Either<List<DeadEnd<Void, String>>, Integer> result = AdvancedParser.run(p, "12");
//
//		assertTrue(result.isRight());
//		assertEquals(12, result.get());
//	}

//	@Test
//	public void intTest_Success_IntOnly() {
//
//		final int intNumber = 15;
//
//		final Either<List<DeadEnd<Void, String>>, Integer> result
//			= AdvancedParser.run(AdvancedParser.integer("expecting an int", "invalid int"), String.valueOf(intNumber));
//
//		assertTrue(result.isRight());
//		assertEquals(intNumber, result.get());
//	}

//	@Test
//	public void intTest_Success_FollowedByAlpha() {
//
//		final int intNumber = 15;
//
//		final Either<List<DeadEnd<Void, String>>, Integer> result
//			= AdvancedParser.run(AdvancedParser.integer("expecting an int", "invalid int"), intNumber + "ab");
//
//		assertTrue(result.isRight());
//		assertEquals(intNumber, result.get());
//	}

//	@Test
//	public void intTest_Invalid_Float() {
//
//		final int intNumber = 15;
//		final double doubleNumber = intNumber + 0.7;
//
//		final Either<List<DeadEnd<Void, String>>, Integer> result
//			= AdvancedParser.run(AdvancedParser.integer("expecting an int", "invalid int"), String.valueOf(doubleNumber));
//
//		assertTrue(result.isLeft());
//
//		List<DeadEnd<Void, String>> deadEnds = result.getLeft();
//
//		assertEquals(1, deadEnds.size());
//		assertEquals(new DeadEnd<>(1, 1, "invalid int", List.of()), deadEnds.get(0));
//	}

//	@Test
//	public void floatTest_Success() {
//
//		final float doubleNumber = 15.7f;
//
//		final Either<List<DeadEnd<Void, String>>, Float> result
//			= AdvancedParser.run(AdvancedParser.floatingPoint("expecting an float", "invalid float"), String.valueOf(doubleNumber));
//
//		assertTrue(result.isRight());
//		assertEquals(doubleNumber, result.get());
//	}

//	@Test
//	public void floatTest_Success_AsInteger() {
//
//		final int doubleNumber = 15;
//
//		final Either<List<DeadEnd<Void, String>>, Float> result
//			= AdvancedParser.run(AdvancedParser.floatingPoint("expecting an float", "invalid float"), String.valueOf(doubleNumber));
//
//		assertTrue(result.isRight());
//		assertEquals(doubleNumber, result.get());
//	}

//	@Test
//	public void spacesTest() {
//
//		final String newLine = "\n";
//		final String carriageReturn = "\r";
//		final String space = " ";
//
//		assertTrue(AdvancedParser.run(AdvancedParser.spaces(), newLine).isRight());
//		assertTrue(AdvancedParser.run(AdvancedParser.spaces(), carriageReturn).isRight());
//		assertTrue(AdvancedParser.run(AdvancedParser.spaces(), space).isRight());
//	}

//	@Test
//	public void tokenTest() {
//
//		final AdvancedParser<Void, String, Void> token = AdvancedParser.token(new Token<>("let", "expecting let"));
//
//		assertTrue(AdvancedParser.run(token, "let").isRight());
//
//		final Either<List<DeadEnd<Void, String>>, Void> result = AdvancedParser.run(token, "abc");
//
//		assertTrue(result.isLeft());
//		assertEquals(1, result.getLeft().size());
//
//		final DeadEnd<Void, String> deadEnd = result.getLeft().get(0);
//
//		assertEquals("expecting let", deadEnd.problem());
//	}

//	@Test
//	public void symbolTest() {
//
//		final AdvancedParser<Void, String, Void> symbol = AdvancedParser.symbol(new Token<>("let", "expecting let"));
//
//		assertTrue(AdvancedParser.run(symbol, "let").isRight());
//
//		final Either<List<DeadEnd<Void, String>>, Void> result = AdvancedParser.run(symbol, "abc");
//
//		assertTrue(result.isLeft());
//		assertEquals(1, result.getLeft().size());
//
//		final DeadEnd<Void, String> deadEnd = result.getLeft().get(0);
//
//		assertEquals("expecting let", deadEnd.problem());
//	}

//	@Test
//	public void endTest() {
//
//		final AdvancedParser<Void, String, Void> end = AdvancedParser.end("expecting end");
//
//		assertTrue(AdvancedParser.run(end, "").isRight());
//
//		final Either<List<DeadEnd<Void, String>>, Void> result = AdvancedParser.run(end, "abc");
//
//		assertTrue(result.isLeft());
//		assertEquals(1, result.getLeft().size());
//
//		final DeadEnd<Void, String> deadEnd = result.getLeft().get(0);
//
//		assertEquals("expecting end", deadEnd.problem());
//	}

//	@Test
//	public void inContextTest() {
//
//		final Either<List<DeadEnd<String, String>>, String> result
//			= AdvancedParser.run(AdvancedParser.inContext("a demo context", AdvancedParser.problem("this is a problem")), "");
//
//		assertTrue(result.isLeft());
//		assertEquals(1, result.getLeft().size());
//		assertEquals(
//			new DeadEnd<>(1, 1, "this is a problem", List.of(new Located<>(1, 1, "a demo context"))),
//			result.getLeft().get(0)
//		);
//	}

//	@Test
//	public void keywordTest() {
//
//		final AdvancedParser<Void, String, Void> let = AdvancedParser.keyword(new Token<>("let", "expected let"));
//
//		final Either<List<DeadEnd<Void, String>>, Void> successful = AdvancedParser.run(let, "let");
//
//		assertTrue(successful.isRight());
//
//		final Either<List<DeadEnd<Void, String>>, Void> result = AdvancedParser.run(let, "xyz");
//
//		assertTrue(result.isLeft());
//		assertEquals(1, result.getLeft().size());
//		assertEquals(
//			new DeadEnd<>(1, 1, "expected let", List.of()),
//			result.getLeft().get(0)
//		);
//	}

//	@Test
//	public void variableTest() {
//
//		final AdvancedParser<Void, String, String> variable
//			= AdvancedParser.variable(
//			Character::isLowerCase,
//			Character::isAlphabetic,
//			Set.of("let"),
//			"an expecting message"
//		);
//
//		final Either<List<DeadEnd<Void, String>>, String> result = AdvancedParser.run(variable, "letter ");
//
//		assertTrue(result.isRight());
//		assertEquals("letter", result.get());
//	}

//	@Test
//	public void consumeBaseTest_Base10() {
//
//		assertEquals(Tuple.of(1, 0), AdvancedParser.consumeBase(10, 0, "0"));
//		assertEquals(Tuple.of(1, 1), AdvancedParser.consumeBase(10, 0, "1"));
//		assertEquals(Tuple.of(1, 1), AdvancedParser.consumeBase(10, 0, "1a"));
//		assertEquals(Tuple.of(2, 12), AdvancedParser.consumeBase(10, 0, "12"));
//
//		// Failing
//		assertEquals(Tuple.of(0, 0), AdvancedParser.consumeBase(10, 0, "abc"));
//		assertEquals(Tuple.of(2, 1), AdvancedParser.consumeBase(10, 1, "a1"));
//	}

//	@Test
//	public void consumeBaseTest_Base2() {
//
//		assertEquals(Tuple.of(1, 0), AdvancedParser.consumeBase(2, 0, "0"));
//		assertEquals(Tuple.of(1, 1), AdvancedParser.consumeBase(2, 0, "1"));
//		assertEquals(Tuple.of(1, 1), AdvancedParser.consumeBase(2, 0, "1a"));
//		assertEquals(Tuple.of(4, 12), AdvancedParser.consumeBase(2, 0, "1100"));
//		assertEquals(Tuple.of(3, 3), AdvancedParser.consumeBase(2, 1, "a11"));
//
//		// Failing
//		assertEquals(Tuple.of(0, 0), AdvancedParser.consumeBase(2, 0, "2"));
//		assertEquals(Tuple.of(0, 0), AdvancedParser.consumeBase(2, 0, "abc"));
//	}

//	@Test
//	public void consumeBaseTest_Base8() {
//
//		assertEquals(Tuple.of(1, 0), AdvancedParser.consumeBase(8, 0, "0"));
//		assertEquals(Tuple.of(1, 1), AdvancedParser.consumeBase(8, 0, "1"));
//		assertEquals(Tuple.of(1, 6), AdvancedParser.consumeBase(8, 0, "6a"));
//		assertEquals(Tuple.of(2, 12), AdvancedParser.consumeBase(8, 0, "14"));
//		assertEquals(Tuple.of(2, 5), AdvancedParser.consumeBase(8, 1, "a5"));
//
//		// Failing
//		assertEquals(Tuple.of(0, 0), AdvancedParser.consumeBase(8, 0, "8"));
//		assertEquals(Tuple.of(0, 0), AdvancedParser.consumeBase(8, 0, "abc"));
//	}
}
