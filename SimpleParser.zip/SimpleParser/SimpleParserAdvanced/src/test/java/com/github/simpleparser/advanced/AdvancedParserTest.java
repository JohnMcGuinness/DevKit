package com.github.simpleparser.advanced;

import com.github.simpleparser.common.DeadEnd;
import com.github.simpleparser.common.Result;
import com.github.simpleparser.common.Token;
import io.vavr.control.Either;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static com.github.simpleparser.advanced.AdvancedParser.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class AdvancedParserTest {

	@Test
	public void succeedTest() {

		int expected = 3;
		final Result<List<DeadEnd<Void, Void>>, Integer> result
			= run(
				succeed(expected),
				"abc"
			);

		assertTrue(result.isOk());
		assertEquals(expected, result.value());
	}

	@Test
	public void problemTest() {

		final String msg = "There was an error";
		final Result<List<DeadEnd<Void, String>>, Integer> result
			= run(
				problem(msg),
				"abc"
			);

		assertTrue(result.isErr());

		final List<DeadEnd<Void, String>> deadEnds = result.error();

		assertNotNull(deadEnds);
		assertEquals(1, deadEnds.size());

		final DeadEnd<Void, String> deadend = deadEnds.get(0);

		assertEquals(1, deadend.row());
		assertEquals(1, deadend.column());
		assertEquals(msg, deadend.problem());
		assertTrue(deadend.contextStack().isEmpty());
	}

	@Test
	public void mapTest() {

		final String expected = "3";
		final AdvancedParser<Void, String, Integer> m = map(Integer::valueOf, succeed(expected));

		final Result<List<DeadEnd<Void, String>>, Integer> result
			= run(
				map(
					Integer::valueOf,
					succeed(expected)
				),
				""
			);

		assertTrue(result.isOk());
		assertEquals(3, result.value());
	}

//    @Test
//    public void keepTest() {
//
////        record Demo2(String value1, String value2) {}
////        Parser<Void, Void, BiFunction<String, String,Demo2>> Demo2 = succeed(Demo2::new);
//
//        record Demo1(String value) { }
//
//        Parser<Void, Void, Integer> p = keep(succeed(Integer::valueOf), succeed("1"));
//
//        Parser<Void, Void, Function<String, Demo1>> Demo1 = succeed(Demo1::new);
//
//
//        Parser<Void, Void, Demo1> p1 = keep(Demo1, succeed("1"));
//
////        Parser<Void, Void, Demo2> p2 = keep(Demo2, succeed("1"));
//
//        /*
//            keep(
//                succeed(Demo::new),
//                succeed("1")
//            );
//        */
//        final Either<List<DeadEnd<Void, Void>>, Integer> result = Parser.run(p, "");
//
//        assertTrue(result.isRight());
//        assertEquals(1, result.get());
//    }

	@Test
	public void andThenTest() {

		final Result<List<DeadEnd<Void, String>>, Integer> result
			= run(
				andThen(
					s -> succeed(s + 5),
					integer("expecting_message", "invalid_message")
				),
				"2"
			);

		assertTrue(result.isOk());
		assertEquals(7, result.value());
	}

	@Test
	public void lazyTest() {

		final var result
			= run(
				lazy(() -> integer("expecting_message", "invalid_message")),
				"12"
			);

		assertTrue(result.isOk());
		assertEquals(12, result.value());
	}

	@Test
	public void intTest_Success_IntOnly() {

		final int intNumber = 15;

		final Result<List<DeadEnd<Void, String>>, Integer> result
			= run(
				integer("expecting an int", "invalid int"),
				String.valueOf(intNumber)
			);

		assertTrue(result.isOk());
		assertEquals(intNumber, result.value());
	}

	@Test
	public void intTest_Success_FollowedByAlpha() {

		final int intNumber = 15;

		final Result<List<DeadEnd<Void, String>>, Integer> result
			= run(
				integer("expecting an int", "invalid int"),
				intNumber + "ab"
			);

		assertTrue(result.isOk());
		assertEquals(intNumber, result.value());
	}

	@Test
	public void integerTest_Invalid_Float() {

		final double doubleNumber = 15.7;

		final Result<List<DeadEnd<Void, String>>, Integer> result
			= run(
				integer("expecting an int", "invalid int"),
				String.valueOf(doubleNumber)
			);

		assertTrue(result.isErr());

		List<DeadEnd<Void, String>> deadEnds = result.error();

		assertEquals(1, deadEnds.size());
		assertEquals(new DeadEnd<>(1, 1, "invalid int", List.of()), deadEnds.get(0));
	}

//	@Test
//	public void floatTest_Success() {
//
//		final float doubleNumber = 15.7f;
//
//		final Either<List<DeadEnd<Void, String>>, Float> result
//			= AdvancedParser.run(AdvancedParser.floatingPoint("expecting an float", "invalid float"), String.valueOf(doubleNumber));
//
//		assertTrue(result.isRight());
//		assertEquals(doubleNumber, result.get());
//	}

//	@Test
//	public void floatTest_Success_AsInteger() {
//
//		final int doubleNumber = 15;
//
//		final Either<List<DeadEnd<Void, String>>, Float> result
//			= AdvancedParser.run(AdvancedParser.floatingPoint("expecting an float", "invalid float"), String.valueOf(doubleNumber));
//
//		assertTrue(result.isRight());
//		assertEquals(doubleNumber, result.get());
//	}

	@Test
	public void spacesTest() {

		final String newLine = "\n";
		final String carriageReturn = "\r";
		final String space = " ";

		assertTrue(run(spaces(), newLine).isOk());

		assertTrue(run(spaces(), carriageReturn).isOk());

		assertTrue(run(spaces(), space).isOk());

		assertTrue(run(spaces(), "c").isOk());
	}

	@Test
	public void tokenTest() {

		final AdvancedParser<Void, String, Void> token = token(new Token<>("let", "expecting let"));

		final Result<List<DeadEnd<Void, String>>, Void> result1
			= run(
				token,
				"let"
			);

		assertTrue(result1.isOk());
		assertNull(result1.value());

		final Result<List<DeadEnd<Void, String>>, Void> result2
			= run(
				token,
				"abc"
			);

		assertTrue(result2.isErr());
		assertEquals(1, result2.error().size());

		final DeadEnd<Void, String> deadEnd = result2.error().get(0);

		assertEquals("expecting let", deadEnd.problem());
	}

	@Test
	public void map2Test()  {

		record MyObject(int i, String s) { }

		final int expectedInteger = 2;
		final String expectedString = "Joe";
		final MyObject expected = new MyObject(expectedInteger, expectedString);

		final Result<List<DeadEnd<Void, String>>, MyObject> result
			= run(
				map2(
					MyObject::new,
					integer("expecting_message", "invalid_message"),
					succeed(expectedString)
				),
				String.valueOf(expectedInteger)
			);

		assertTrue(result.isOk());
		assertEquals(expected, result.value());
	}
//	@Test
//	public void symbolTest() {
//
//		final AdvancedParser<Void, String, Void> symbol = AdvancedParser.symbol(new Token<>("let", "expecting let"));
//
//		assertTrue(AdvancedParser.run(symbol, "let").isRight());
//
//		final Either<List<DeadEnd<Void, String>>, Void> result = AdvancedParser.run(symbol, "abc");
//
//		assertTrue(result.isLeft());
//		assertEquals(1, result.getLeft().size());
//
//		final DeadEnd<Void, String> deadEnd = result.getLeft().get(0);
//
//		assertEquals("expecting let", deadEnd.problem());
//	}

	@Test
	public void endTest() {

		final AdvancedParser<Void, String, Void> end = end("expecting end");

		final Result<List<DeadEnd<Void, String>>, Void> result1
			= run(
				end,
				""
			);

		assertTrue(result1.isOk());
		assertNull(result1.value());

		final Result<List<DeadEnd<Void, String>>, Void> result2
			= run(
				end,
				"abc"
			);

		assertTrue(result2.isErr());
		assertEquals(1, result2.error().size());

		final DeadEnd<Void, String> deadEnd = result2.error().get(0);
		assertEquals("expecting end", deadEnd.problem());
	}

//	@Test
//	public void inContextTest() {
//
//		final Either<List<DeadEnd<String, String>>, String> result
//			= AdvancedParser.run(AdvancedParser.inContext("a demo context", AdvancedParser.problem("this is a problem")), "");
//
//		assertTrue(result.isLeft());
//		assertEquals(1, result.getLeft().size());
//		assertEquals(
//			new DeadEnd<>(1, 1, "this is a problem", List.of(new Located<>(1, 1, "a demo context"))),
//			result.getLeft().get(0)
//		);
//	}

//	@Test
//	public void keywordTest() {
//
//		final AdvancedParser<Void, String, Void> let = AdvancedParser.keyword(new Token<>("let", "expected let"));
//
//		final Either<List<DeadEnd<Void, String>>, Void> successful = AdvancedParser.run(let, "let");
//
//		assertTrue(successful.isRight());
//
//		final Either<List<DeadEnd<Void, String>>, Void> result = AdvancedParser.run(let, "xyz");
//
//		assertTrue(result.isLeft());
//		assertEquals(1, result.getLeft().size());
//		assertEquals(
//			new DeadEnd<>(1, 1, "expected let", List.of()),
//			result.getLeft().get(0)
//		);
//	}

	@Test
	public void variableTest() {

		final AdvancedParser<Void, String, String> variable
			= variable(
				Character::isJavaIdentifierStart,
				Character::isJavaIdentifierPart,
				Set.of("let"),
				"an expecting message"
			);

		final Result<List<DeadEnd<Void, String>>, String> result
			= run(
				variable,
				"letter "
			);

		assertTrue(result.isOk());
		assertEquals("letter", result.value());
	}
}
