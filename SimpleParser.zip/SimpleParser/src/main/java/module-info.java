module SimpleParser {
    requires io.vavr;
    exports com.github.johnmcguinness.simpleparser;
}