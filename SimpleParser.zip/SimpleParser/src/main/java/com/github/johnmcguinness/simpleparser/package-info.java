/**
 * Contains {@link com.github.johnmcguinness.simpleparser.Parser} and associated classes required to use it.
 */
package com.github.johnmcguinness.simpleparser;
