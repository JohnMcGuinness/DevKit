package com.github.johnmcguinness.simpleparser;

import io.vavr.Tuple;
import io.vavr.Tuple2;
import io.vavr.Tuple3;
import io.vavr.control.Either;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * A {@link Parser} helps turn a {@link String} into nicely structured data. For example, we can {@code run} the {@link Parser#integer} parser
 * to turn {@link String} to {@link Integer}:
 *
 * <blockquote><pre>
 *     Parser.run(integer(), "123456");
 *     // returns Ok(123456)
 *
 *     Parser.run(integer(), "3.1415");
 *     // returns Err(...)
 * </pre></blockquote>
 * <p>
 * The cool thing is that you can combine `Parser` values to handle much more complex scenarios.
 * <p>
 * <strong>Attribution</strong>: This library is a port of the Elm/Parser library from the Elm Language to Java&trade;. I'd like to attribute
 * Evan Cziplicki with the API design. I merely rewrote the logic in Java&trade;, although there are some parts of the API that
 * had to be modified, or omitted, due to the constraints of the Java&trade; language.
 *
 * @param <C> context
 * @param <X> problem
 * @param <T> value
 *
 * @see <a href="https://github.com/elm/parser">elm/parser</a>
 */
public final class Parser<C, X, T> {

	private final Function<State<C>, PStep<C, X, T>> parse;

	private Parser(final Function<State<C>, PStep<C, X, T>> parse) {
		this.parse = parse;
	}

	/**
	 * This works just like {@link Parser#run}. The only difference is that when it fails, it has much more
	 * precise information for each dead end.
	 *
	 * @param parser the parser to run
	 * @param source the {@link String} for the parser to parse
	 * @param <C> context
	 * @param <X> problem
	 * @param <T> value
	 *
	 * @return the result of running the parser
	 */
	public static <C, X, T> Either<List<DeadEnd<C, X>>, T> run(final Parser<C, X, T> parser, final String source) {
		final Function<State<C>, PStep<C, X, T>> parse = parser.parse;

		PStep<C, X, T> pStep = parse.apply(new State<>(source, 0, 1, List.of(), 1, 1));

		if (pStep instanceof Good<C, X, T> good) {
			return Either.right(good.value());
		} else { // Must be an instance of bad
			final Bad<C, X, T> bad = (Bad<C, X, T>) pStep;

			return Either.left(Bag.bagToList(bad.bag(), io.vavr.collection.List.empty()).toJavaList());
		}
	}

	/**
	 * Just like {@link Parser#succeed}.
	 *
	 * @param value the value that the parser should return.
	 * @param <C>   context
	 * @param <X>   problem
	 * @param <T>   value
	 * @return a parser that always succeeds with the argument passed in.
	 */
	public static <C, X, T> Parser<C, X, T> succeed(final T value) {
		return new Parser<>((s) -> new Good<>(false, value, s));
	}

	/**
	 * Just like {@link Parser#problem} except you provide a type for the problem.
	 *
	 * @param problem
	 * @param <C> context
	 * @param <X> problem
	 * @param <T> value
	 * @return a {@link Parser} that always fails with the provided problem.
	 */
	public static <C, X, T> Parser<C, X, T> problem(final X problem) {
		return new Parser<>(s -> new Bad<>(false, Bag.fromState(s, problem)));
	}

	/**
	 * Just like {@link Parser#map}.
	 *
	 * @param f the {@link Function} to be applied to the result of invoking {@code parser}.
	 * @param parser the {@link Parser} to invoke first.
	 *
	 * @param <C> context
	 * @param <X> problem
	 * @param <T> value
	 * @param <R> result
	 * @return a {@link Parser} that transforms the result of another {@link Parser}.
	 */
	public static <C, X, T, R> Parser<C, X, R> map(final Function<T, R> f, final Parser<C, X, T> parser) {

		return new Parser<>(s -> {

			final PStep<C, X, T> result = parser.parse.apply(s);

			if (result instanceof Good<C, X, T> good) {
				return new Good<>(good.progress(), f.apply(good.value()), good.state());
			} else { // Must be an instance of bad
				final Bad<C, X, T> bad = (Bad<C, X, T>) result;
				return new Bad<>(bad.progress(), bad.bag());
			}
		});
	}

	/**
	 * Combines the results of two {@link Parser}s.
	 *
	 * @param f the {@link BiFunction} that will combine the results of {@code parserA} and {@code parserB} to produce an {@code R}.
	 * @param parserA the {@link Parser} to invoke first.
	 * @param parserB if {@code parserA} parses successfully then {@code parserB} is invoked.
	 *
	 * @param <C> context
	 * @param <X> problem
	 * @param <T1> value of {@code parserA}
	 * @param <T2> value of {@code parserB}
	 * @param <R> value of the returned {@link Parser}
	 * @return a {@link Parser} that combines the result of two other {@link Parser}s.
	 */
	public static <C, X, T1, T2, R> Parser<C, X, R> map2(final BiFunction<T1, T2, R> f, final Parser<C, X, T1> parserA, final Parser<C, X, T2> parserB) {
		return new Parser<>((s0) -> {

			final PStep<C, X, T1> resultA = parserA.parse.apply(s0);

			if (resultA instanceof Bad<C, X, T1> badA) {
				return new Bad<>(badA.progress(), badA.bag());
			} else { // Must be an instance of good
				final Good<C, X, T1> goodA = (Good<C, X, T1>) resultA;
				final PStep<C, X, T2> resultB = parserB.parse.apply(goodA.state());

				if (resultB instanceof Bad<C, X, T2> badB) {
					return new Bad<>(goodA.progress() || badB.progress(), badB.bag());
				} else { // Must be an instance of good
					final Good<C, X, T2> goodB = (Good<C, X, T2>) resultB;
					return new Good<>(goodA.progress() || goodB.progress(), f.apply(goodA.value(), goodB.value()), goodB.state());
				}
			}
		});
	}

	public static <C, X, T, R> Parser<C, X, R> keep(final Parser<C, X, Function<T, R>> parseFunc, final Parser<C, X, T> parseArg) {
		return map2(Function::apply, parseFunc, parseArg);
	}

	/**
	 * Just like {@link }Parser#andThen}.
	 *
	 * @param callback applied to the result of {@code parser}
	 * @param parser
	 * @param <C> context
	 * @param <X> problem
	 * @param <T> value of {@code parser}
	 * @param <R> value of the returned {@link Parser}
	 * @return a {@link Parser} that transforms the result of another {@link Parser}.
	 */
	public static <C, X, T, R> Parser<C, X, R> andThen(final Function<T, Parser<C, X, R>> callback, final Parser<C, X, T> parser) {

		return new Parser<>(state -> {

			final PStep<C, X, T> resultA = parser.parse.apply(state);

			if (resultA instanceof Bad<C, X, T> badA) {
				return new Bad<>(badA.progress(), badA.bag());
			} else {
				final Good<C, X, T> goodA = (Good<C, X, T>) resultA;
				final Parser<C, X, R> parserB = callback.apply(goodA.value());
				final PStep<C, X, R> resultB = parserB.parse.apply(goodA.state());

				if (resultB instanceof Bad<C, X, R> badB) {
					return new Bad<>(goodA.progress() || badB.progress(), badB.bag());
				} else {
					final Good<C, X, R> goodB = (Good<C, X, R>) resultB;
					return new Good<>(goodA.progress() || goodB.progress(), goodB.value(), goodB.state());
				}
			}
		});
	}

	public static <C, X, T> Parser<C, X, T> lazy(final Supplier<Parser<C, X, T>> thunk) {
		return new Parser<>(s -> thunk.get().parse.apply(s));
	}

	public static <C, X> Parser<C, X, Void> token(final Token<X> token) {

		final boolean progress = !token.string().isEmpty();

		return new Parser<>(s -> {

			final Tuple3<Integer, Integer, Integer> triple = isSubString(token.string(), s.offset(), s.row(), s.column(), s.source());

			final int newOffset = triple._1;
			final int newRow = triple._2;
			final int newCol = triple._3;

			if (newOffset == -1) {
				return new Bad<>(false, Bag.fromState(s, token.expecting()));
			} else {
				return new Good<>(progress, null, new State<>(s.source(), newOffset, s.indent(), s.context(), newRow, newCol));
			}
		});
	}

	public static <C, X> Parser<C, X, Void> symbol(final Token<X> token) {
		return token(token);
	}

	public static <C, X> Parser<C, X, Void> end(final X expecting) {

		return new Parser<>(s -> {

			if (s.source().length() == s.offset()) {
				return new Good<>(false, null, s);
			} else {
				return new Bad<>(false, Bag.fromState(s, expecting));
			}
		});
	}

	public static <C, X> Parser<C, X, Integer> integer(final X expecting, final X invalid) {
		return number(new NumberConfig<>(
				Either.right(Function.identity()),
				Either.left(invalid),
				Either.left(invalid),
				Either.left(invalid),
				Either.left(invalid),
				invalid,
				expecting));
	}

	public static <C, X> Parser<C, X, Float> floatingPoint(final X expecting, final X invalid) {
		return number(new NumberConfig<>(
				Either.right(Float::valueOf),
				Either.left(invalid),
				Either.left(invalid),
				Either.left(invalid),
				Either.right(Function.identity()),
				invalid,
				expecting));
	}

	public static <C, X, T> Parser<C, X, T> number(final NumberConfig<X, T> config) {

		return new Parser<>(s -> {

			if (isAsciiCode(0x30, s.offset(), s.source())) {

				final int zeroOffset = s.offset() + 1;
				final int baseOffset = zeroOffset + 1;

				if (isAsciiCode(0x78, zeroOffset, s.source())) {
					return finaliseInt(config.invalid(), config.hexadecimal(), baseOffset, consumeBase16(baseOffset, s.source()), s);
				} else if (isAsciiCode(0x6F, zeroOffset, s.source())) {
					return finaliseInt(config.invalid(), config.octal(), baseOffset, consumeBase(8, baseOffset, s.source()), s);
				} else if (isAsciiCode(0x62, zeroOffset, s.source())) {
					return finaliseInt(config.invalid(), config.binary(), baseOffset, consumeBase(2, baseOffset, s.source()), s);
				} else {
					return finaliseFloat(config.invalid(), config.expecting(), config.decimalInteger(), config.floatingPoint(), Tuple.of(zeroOffset, 0), s);
				}
			} else {
				return finaliseFloat(config.invalid(), config.expecting(), config.decimalInteger(), config.floatingPoint(), consumeBase(10, s.offset(), s.source()), s);
			}
		});
	}

	public static <C, X, T> Parser<C, X, T> inContext(final C context, final Parser<C, X, T> parser) {

		return new Parser<>(s0 -> {

			final List<Located<C>> newContextStack = new ArrayList<>(s0.context());
			if (newContextStack.isEmpty()) {
				newContextStack.add(new Located<>(s0.row(), s0.column(), context));
			} else {
				newContextStack.set(0, new Located<>(s0.row(), s0.column(), context));
			}

			final PStep<C, X, T> result = parser.parse.apply(changeContext(newContextStack, s0));

			if (result instanceof Good<C, X, T> good) {
				return new Good<>(good.progress(), good.value(), changeContext(s0.context(), good.state()));
			} else {
				return result;
			}
		});
	}

	public static <C, X> Parser<C, X, Void> keyword(final Token<X> token) {

		final String kwd = token.string();
		final X expecting = token.expecting();

		final boolean progress = !kwd.isEmpty();

		return new Parser<>(s -> {

			final Tuple3<Integer, Integer, Integer> triple = isSubString(token.string(), s.offset(), s.row(), s.column(), s.source());

			final int newOffset = triple._1;
			final int newRow = triple._2;
			final int newCol = triple._3;

			if (newOffset == -1 || 0 <= isSubChar(c -> Character.isLetterOrDigit(c) || c == '_', newOffset, s.source())) {
				return new Bad<>(false, Bag.fromState(s, expecting));
			} else {
				return new Good<>(progress, null, new State<>(s.source(), newOffset, s.indent(), s.context(), newRow, newCol));
			}
		});
	}

	public static <C, X> Parser<C, X, String> variable(final Predicate<Integer> start, final Predicate<Integer> inner, final Set<String> reserved, final X expecting) {

		return new Parser<>(s -> {

			final int firstOffset = isSubChar(start, s.offset(), s.source());

			if (firstOffset == -1) {
				return new Bad<>(false, Bag.fromState(s, expecting));
			} else {

				final State<C> s1 = firstOffset == -2
						? varHelp(inner, s.offset() + 1, s.row() + 1, 1, s.source(), s.indent(), s.context())
						: varHelp(inner, firstOffset, s.row(), s.column() + 1, s.source(), s.indent(), s.context());

				final String name = s.source().substring(s.offset(), s1.offset());

				if (reserved.contains(name)) {
					return new Bad<>(false, Bag.fromState(s, expecting));
				} else {
					return new Good<>(true, name, s1);
				}
			}
		});
	}

	private static <C> State<C> varHelp(
			final Predicate<Integer> isGood,
			final int offset,
			final int row,
			final int column,
			final String source,
			final int indent,
			final List<Located<C>> context) {

		final int newOffset = isSubChar(isGood, offset, source);

		if (newOffset == -1) {
			return new State<>(source, offset, indent, context, row, column);
		} else if (newOffset == -2) {
			return varHelp(isGood, offset + 1, row + 1, 1, source, indent, context);
		} else {
			return varHelp(isGood, newOffset, row, column + 1, source, indent, context);
		}
	}

	private static <C> State<C> changeContext(final List<Located<C>> newContext, final State<C> s) {
		return new State<>(s.source(), s.offset(), s.indent(), newContext, s.row(), s.column());
	}

	private static boolean isAsciiCode(final int code, final int offset, final String string) {
		return offset < string.length() && string.codePointAt(offset) == code;
	}

	static Tuple2<Integer, Integer> consumeBase(final int base, final int initialOffset, final String string) {

		int offset = initialOffset;
		int result = 0;

		for (; offset < string.length(); offset++) {
			int digit = string.charAt(offset) - 0x30;
			if (digit < 0 || base <= digit) {
				break;
			}
			result = base * result + digit;
		}

		return Tuple.of(offset, result);
	}

	private static Tuple2<Integer, Integer> consumeBase16(final int initialOffset, final String string) {

		int offset = initialOffset;
		int total = 0;

		for (; offset < string.length(); offset++) {

			final int code = string.charAt(offset);

			if (0x30 <= code && code <= 0x39) {
				total = 16 * total + code - 0x30;
			} else if (0x41 <= code && code <= 0x46) {
				total = 16 * total + code - 55;
			} else if (0x61 <= code && code <= 0x66) {
				total = 16 * total + code - 87;
			} else {
				break;
			}
		}

		return Tuple.of(offset, total);
	}

	private static <C, X, T> PStep<C, X, T> finaliseFloat(
			final X invalid,
			final X expecting,
			final Either<X, Function<Integer, T>> intSettings,
			final Either<X, Function<Float, T>> floatSettings,
			final Tuple2<Integer, Integer> intPair,
			final State<C> s) {

		final int intOffset = intPair._1;
		final int floatOffset = consumeDotAndExp(intOffset, s.source());

		if (floatOffset < 0) {
			return new Bad<>(true, Bag.fromInfo(s.row(), (s.column() - (floatOffset + s.offset())), invalid, s.context()));
		} else if (s.offset() == floatOffset) {
			return new Bad<>(false, Bag.fromState(s, expecting));
		} else if (intOffset == floatOffset) {
			return finaliseInt(invalid, intSettings, s.offset(), intPair, s);
		} else {
			if (floatSettings.isLeft()) {
				return new Bad<>(true, Bag.fromState(s, invalid));
			} else {
				final Function<Float, T> toValue = floatSettings.get();

				try {
					final Float value = Float.valueOf(s.source().substring(s.offset(), floatOffset));

					return new Good<>(true, toValue.apply(value), bumpOffset(floatOffset, s));
				} catch (NumberFormatException e) {

				}
				return null;
			}
		}
	}

	private static <C, X, T> PStep<C, X, T> finaliseInt(
			final X invalid,
			final Either<X, Function<Integer, T>> handler,
			final int startOffset,
			final Tuple2<Integer, Integer> tuple,
			final State<C> s) {
		if (handler.isLeft()) {
			return new Bad<>(true, Bag.fromState(s, handler.getLeft()));
		} else {
			final Function<Integer, T> toValue = handler.get();

			if (startOffset == tuple._1) {
				return new Bad<>((s.offset() < startOffset), Bag.fromState(s, invalid));
			} else {
				return new Good<>(true, toValue.apply(tuple._2), bumpOffset(tuple._1, s));
			}
		}
	}

	private static int consumeDotAndExp(final int offset, final String source) {
		if (isAsciiCode(0x2E, offset, source)) {
			return consumeExp(chompBase10((offset + 1), source), source);
		} else {
			return consumeExp(offset, source);
		}
	}

	private static int consumeExp(final int offset, final String source) {
		if (isAsciiCode(0x65, offset, source) || isAsciiCode(0x45, offset, source)) {

			int eOffset = offset + 1;
			int expOffset = (isAsciiCode(0x2B, eOffset, source) || isAsciiCode(0x2D, eOffset, source)) ? eOffset + 1 : eOffset;
			int newOffset = chompBase10(expOffset, source);

			if (expOffset == newOffset) {
				return -1 * newOffset;
			} else {
				return newOffset;
			}
		} else {
			return offset;
		}
	}

	private static int chompBase10(final int initialOffset, final String string) {

		int offset = initialOffset;

		for (; offset < string.length(); offset++) {
			int code = string.codePointAt(offset);

			if (code < 0x30 || 0x39 < code) {
				return offset;
			}
		}

		return offset;
	}

	private static <C, X> Parser<C, X, Void> chompWhile(final Predicate<Integer> isGood) {
		return new Parser<>(s -> chompWhileHelp(isGood, s.offset(), s.row(), s.column(), s));
	}

	private static <C, X> PStep<C, X, Void> chompWhileHelp(final Predicate<Integer> isGood, final int offset, final int row, final int column, final State<C> s0) {

		final int newOffset = isSubChar(isGood, offset, s0.source());

		if (newOffset == -1) {
			return new Good<>(s0.offset() < offset, null, new State<>(s0.source(), offset, s0.indent(), s0.context(), row, column));
		} else if (newOffset == -2) {
			return chompWhileHelp(isGood, offset + 1, row + 1, 1, s0);
		} else {
			return chompWhileHelp(isGood, newOffset, row, column + 1, s0);
		}
	}

	/**
	 * Parse zero or more charactes that match {@code Character::isWhitespace}.
	 * The implementation is pretty simple:
	 *
	 * <blockquote><pre>
	 *     Parser&lt;Void&gt; spaces = chompWhile(Character::isWhitespace);
	 * </pre></blockquote>
	 * <p>
	 * So if you need something different (like tabs) just define an alternative with the necessary tweaks! Check out
	 * {@link lineComment} and {@link multiComment} for more complex situations.
	 *
	 * @param <C> context
	 * @param <X> problem
	 * @return a Parser that parses spaces.
	 */
	public static <C, X> Parser<C, X, Void> spaces() {
		return chompWhile(Character::isWhitespace);
	}

	static int isSubChar(final Predicate<Integer> predicate, final int offset, final String string) {

		if (string.length() <= offset) {
			return -1;
		}

		final int codePoint = string.codePointAt(offset);

		if (predicate.test(codePoint)) {
			final String subChar = Character.toString(codePoint);
			return codePoint == '\n' ? -2 : offset + subChar.length();
		} else {
			return -1;
		}
	}

	static Tuple3<Integer, Integer, Integer> isSubString(final String shorterString, final int offset, final int row, final int col, final String longerString) {

		final String substring = longerString.substring(offset, offset + shorterString.length());

		if (shorterString.equals(substring)) {

			final int newOffset = offset + substring.length();
			final int newRow = row + ((int) substring.lines().count() - 1);
			final int newColumn = ((substring.lastIndexOf('\n') == -1) ? col + substring.length() : substring.length() - substring.lastIndexOf('\n'));

			return Tuple.of(newOffset, newRow, newColumn);
		} else {
			return Tuple.of(-1, row, col);
		}
	}

	private static <C> State<C> bumpOffset(final int newOffset, final State<C> s) {
		return new State<>(s.source(), newOffset, s.indent(), s.context(), s.row(), s.column() + (newOffset - s.offset()));
	}
}

record NumberConfig<X, T>(
		Either<X, Function<Integer, T>> decimalInteger,
		Either<X, Function<Integer, T>> hexadecimal,
		Either<X, Function<Integer, T>> octal,
		Either<X, Function<Integer, T>> binary,
		Either<X, Function<Float, T>> floatingPoint,
		X invalid,
		X expecting) {
}

record VariableConfig<X>(Predicate<Integer> start, Predicate<Integer> inner, Set<String> reserved, X expecting) {
}

record State<T>(String source, int offset, int indent, List<Located<T>> context, int row, int column) {
}

record Located<T>(int row, int column, T context) {
}

record DeadEnd<C, X>(int row, int col, X problem, List<Located<C>> contextStack) {
}

// Bag
sealed interface Bag<C, X> permits Empty, AddRight, Append {

	static <C, X> Bag<C, X> fromState(final State<C> state, X x) {
		return new AddRight<>(new Empty<>(), new DeadEnd<>(state.row(), state.column(), x, state.context()));
	}

	static <C, X> Bag<C, X> fromInfo(final int row, final int col, final X x, final List<Located<C>> context) {
		return new AddRight<>(new Empty<>(), new DeadEnd<>(row, col, x, context));
	}

	static <C, X> io.vavr.collection.List<DeadEnd<C, X>> bagToList(final Bag<C, X> bag, final io.vavr.collection.List<DeadEnd<C, X>> list) {

		if (bag instanceof Empty) {
			return list;
		} else if (bag instanceof AddRight<C, X> addRight) {
			return bagToList(addRight.bag(), list.prepend(addRight.deadend()));
		} else {
			final Append<C, X> append = (Append<C, X>) bag;
			return bagToList(append.left(), bagToList(append.right(), list));
		}
	}
}

record Token<X>(String string, X expecting) {
}

record Empty<C, X>() implements Bag<C, X> {
}

record AddRight<C, X>(Bag<C, X> bag, DeadEnd<C, X> deadend) implements Bag<C, X> {
}

record Append<C, X>(Bag<C, X> left, Bag<C, X> right) implements Bag<C, X> {
}

sealed interface PStep<C, X, T> permits Good, Bad {
}

record Good<C, X, T>(boolean progress, T value, State<C> state) implements PStep<C, X, T> {
}

record Bad<C, X, T>(boolean progress, Bag<C, X> bag) implements PStep<C, X, T> {
}
