package com.github.simpleparser.common;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

public class ConsumeBaseTest {

	@Test
	public void consumeBaseTest_Base10() {

		assertArrayEquals(new int[]{1, 0}, ParserImpl.consumeBase(10, 0, "0"));
		assertArrayEquals(new int[]{1, 1}, ParserImpl.consumeBase(10, 0, "1"));
		assertArrayEquals(new int[]{1, 1}, ParserImpl.consumeBase(10, 0, "1a"));
		assertArrayEquals(new int[]{2, 12}, ParserImpl.consumeBase(10, 0, "12"));

		// Failing
		assertArrayEquals(new int[]{0, 0}, ParserImpl.consumeBase(10, 0, "abc"));
		assertArrayEquals(new int[]{2, 1}, ParserImpl.consumeBase(10, 1, "a1"));
	}

	@Test
	public void consumeBaseTest_Base2() {

		assertArrayEquals(new int[]{1, 0}, ParserImpl.consumeBase(2, 0, "0"));
		assertArrayEquals(new int[]{1, 1}, ParserImpl.consumeBase(2, 0, "1"));
		assertArrayEquals(new int[]{1, 1}, ParserImpl.consumeBase(2, 0, "1a"));
		assertArrayEquals(new int[]{4, 12}, ParserImpl.consumeBase(2, 0, "1100"));
		assertArrayEquals(new int[]{3, 3}, ParserImpl.consumeBase(2, 1, "a11"));

		// Failing
		assertArrayEquals(new int[]{0, 0}, ParserImpl.consumeBase(2, 0, "2"));
		assertArrayEquals(new int[]{0, 0}, ParserImpl.consumeBase(2, 0, "abc"));
	}

	@Test
	public void consumeBaseTest_Base8() {

		assertArrayEquals(new int[]{1, 0}, ParserImpl.consumeBase(8, 0, "0"));
		assertArrayEquals(new int[]{1, 1}, ParserImpl.consumeBase(8, 0, "1"));
		assertArrayEquals(new int[]{1, 6}, ParserImpl.consumeBase(8, 0, "6a"));
		assertArrayEquals(new int[]{2, 12}, ParserImpl.consumeBase(8, 0, "14"));
		assertArrayEquals(new int[]{2, 5}, ParserImpl.consumeBase(8, 1, "a5"));

		// Failing
		assertArrayEquals(new int[]{0, 0}, ParserImpl.consumeBase(8, 0, "8"));
		assertArrayEquals(new int[]{0, 0}, ParserImpl.consumeBase(8, 0, "abc"));
	}
}
