package com.github.simpleparser.common;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class FindSubStringTest {

	@Test
	public void test() {

		final String shorter = "let";
		final String longer = "letter";

		final int[] result = ParserImpl.findSubString(shorter, 0, 1,1, longer);

		assertEquals(0, result[0]);
	}
}
