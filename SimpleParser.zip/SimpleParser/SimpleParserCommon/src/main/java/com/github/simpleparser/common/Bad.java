package com.github.simpleparser.common;

import com.github.simpleparser.common.internal.Bag;

public record Bad<C, X, T>(boolean progress, Bag<C, X> bag) implements PStep<C, X, T> { }
