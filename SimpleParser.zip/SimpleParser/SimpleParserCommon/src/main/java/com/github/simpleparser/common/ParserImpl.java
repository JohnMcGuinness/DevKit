package com.github.simpleparser.common;

import io.vavr.Tuple;
import io.vavr.Tuple3;
import io.vavr.control.Either;

import com.github.simpleparser.common.internal.Bag;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public final class ParserImpl {

	private ParserImpl() { }

	public static <C, X, T> Either<List<DeadEnd<C, X>>, T> run(final AbstractParser<C, X, T> parser, final String source) {
		final Function<State<C>, PStep<C, X, T>> parse = parser.parse();

		final PStep<C, X, T> pStep = parse.apply(new State<>(source, 0, 1, List.of(), 1, 1));

		if (pStep instanceof Good<C, X, T> good) {
			return Either.right(good.value());
		} else { // Must be an instance of bad
			final Bad<C, X, T> bad = (Bad<C, X, T>) pStep;

			return Either.left(Bag.bagToList(bad.bag(), io.vavr.collection.List.empty()).toJavaList());
		}
	}

	public static <C, X, T> Function<State<C>, PStep<C, X, T>> succeedF(final T value) {
		return state -> new Good<>(false, value, state);
	}

	public static <C, X, T> Function<State<C>, PStep<C, X, T>> problemF(final X problem) {
		return state -> new Bad<>(false, Bag.fromState(state, problem));
	}

	public static <C, X, T, R> Function<State<C>, PStep<C, X, R>> mapF(final Function<T, R> f, final AbstractParser<C, X, T> parser) {

		return state -> {

			final PStep<C, X, T> result = parser.parse().apply(state);

			if (result instanceof Good<C, X, T> good) {
				return new Good<>(good.progress(), f.apply(good.value()), good.state());
			} else { // Must be an instance of bad
				final Bad<C, X, T> bad = (Bad<C, X, T>) result;
				return new Bad<>(bad.progress(), bad.bag());
			}
		};
	}

	public static <C, X, T, R> Function<State<C>, PStep<C, X, R>> andThenF(final Function<T, ? extends AbstractParser<C, X, R>> callback, final AbstractParser<C, X, T> parser) {

		return state -> {

			final PStep<C, X, T> resultA = parser.parse().apply(state);

			if (resultA instanceof Bad<C, X, T> badA) {
				return new Bad<>(badA.progress(), badA.bag());
			} else {
				final Good<C, X, T> goodA = (Good<C, X, T>) resultA;
				final AbstractParser<C, X, R> parserB = callback.apply(goodA.value());
				final PStep<C, X, R> resultB = parserB.parse().apply(goodA.state());

				if (resultB instanceof Bad<C, X, R> badB) {
					return new Bad<>(goodA.progress() || badB.progress(), badB.bag());
				} else {
					final Good<C, X, R> goodB = (Good<C, X, R>) resultB;
					return new Good<>(goodA.progress() || goodB.progress(), goodB.value(), goodB.state());
				}
			}
		};
	}

	public static Tuple3<Integer, Integer, Integer> isSubString(
		final String shorterString,
		final int offset,
		final int row,
		final int col,
		final String longerString
	) {

		final String substring = longerString.substring(offset, offset + shorterString.length());

		if (shorterString.equals(substring)) {

			final int newOffset = offset + substring.length();
			final int newRow = row + ((int) substring.lines().count() - 1);
			final int newColumn =
				((substring.lastIndexOf('\n') == -1)
					? col + substring.length()
					: substring.length() - substring.lastIndexOf('\n'));

			return Tuple.of(newOffset, newRow, newColumn);
		} else {
			return Tuple.of(-1, row, col);
		}
	}

	public static int isSubChar(final Predicate<Integer> predicate, final int offset, final String string) {

		if (string.length() <= offset) {
			return -1;
		}

		final int codePoint = string.codePointAt(offset);

		if (predicate.test(codePoint)) {
			final String subChar = Character.toString(codePoint);
			return codePoint == '\n' ? -2 : offset + subChar.length();
		} else {
			return -1;
		}
	}
}
