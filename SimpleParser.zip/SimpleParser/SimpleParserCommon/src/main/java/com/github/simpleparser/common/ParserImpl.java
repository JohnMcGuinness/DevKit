package com.github.simpleparser.common;

import com.github.simpleparser.common.internal.Bag;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public final class ParserImpl {

	private ParserImpl() { }

	public static <C, X, T> Result<List<DeadEnd<C, X>>, T> run(
		final AbstractParser<C, X, T> parser,
		final String source
	) {

		final Function<State<C>, PStep<C, X, T>> parse = parser.parse();

		final PStep<C, X, T> pStep = parse.apply(new State<>(source, 0, 1, List.of(), 1, 1));

		if (pStep instanceof Good<C, X, T> good) {
			return new Ok<>(good.value());
		} else { // Must be an instance of bad
			final Bad<C, X, T> bad = (Bad<C, X, T>) pStep;

			return new Err<>(Bag.bagToList(bad.bag(), io.vavr.collection.List.empty()).toJavaList());
		}
	}

	public static <C, X, T> Function<State<C>, PStep<C, X, T>> succeedF(final T value) {
		return state -> new Good<>(false, value, state);
	}

	public static <C, X, T> Function<State<C>, PStep<C, X, T>> problemF(final X problem) {
		return state -> new Bad<>(false, Bag.fromState(state, problem));
	}

	public static <C, X, T, R> Function<State<C>, PStep<C, X, R>> mapF(
		final Function<T, R> f,
		final AbstractParser<C, X, T> parser
	) {

		return state -> {

			final PStep<C, X, T> result = parser.parse().apply(state);

			if (result instanceof Good<C, X, T> good) {
				return new Good<>(good.progress(), f.apply(good.value()), good.state());
			} else { // Must be an instance of bad
				final Bad<C, X, T> bad = (Bad<C, X, T>) result;
				return new Bad<>(bad.progress(), bad.bag());
			}
		};
	}

	public static <C, X, T, R> Function<State<C>, PStep<C, X, R>> andThenF(
		final Function<T, ? extends AbstractParser<C, X, R>> callback,
		final AbstractParser<C, X, T> parser
	) {
		return state -> {

			final PStep<C, X, T> resultA = parser.parse().apply(state);

			if (resultA instanceof Bad<C, X, T> badA) {
				return new Bad<>(badA.progress(), badA.bag());
			} else {
				final Good<C, X, T> goodA = (Good<C, X, T>) resultA;
				final AbstractParser<C, X, R> parserB = callback.apply(goodA.value());
				final PStep<C, X, R> resultB = parserB.parse().apply(goodA.state());

				if (resultB instanceof Bad<C, X, R> badB) {
					return new Bad<>(goodA.progress() || badB.progress(), badB.bag());
				} else {
					final Good<C, X, R> goodB = (Good<C, X, R>) resultB;
					return new Good<>(goodA.progress() || goodB.progress(), goodB.value(), goodB.state());
				}
			}
		};
	}

	public static <C, X, T> Function<State<C>, PStep<C, X, T>> lazyF(final Supplier<? extends AbstractParser<C, X, T>> thunk) {
		return s -> thunk.get().parse().apply(s);
	}

	public static <C, X> Function<State<C>, PStep<C, X, Void>> tokenF(final Token<X> token) {

		final boolean progress = !token.string().isEmpty();

		return state -> {

			final int[] triple
				= ParserImpl.isSubString(token.string(), state.offset(), state.row(), state.column(), state.source());

			final int newOffset = triple[0];
			final int newRow = triple[1];
			final int newCol = triple[2];

			if (newOffset == -1) {
				return new Bad<>(false, Bag.fromState(state, token.expecting()));
			} else {
				return new Good<>(progress, null,
					new State<>(state.source(), newOffset, state.indent(), state.context(), newRow, newCol));
			}
		};
	}

	public static <C, X, T> Function<State<C>, PStep<C, X, T>> number(
		final Result<X, Function<Integer, T>> decimalInteger,
		final Result<X, Function<Integer, T>> hexadecimal,
		final Result<X, Function<Integer, T>> octal,
		final Result<X, Function<Integer, T>> binary,
		final Result<X, Function<Float, T>> floatingPoint,
		final X invalid,
		final X expecting
	) {

		final int decimalBase = 10;
		final int octalBase = 8;
		final int binaryBase = 2;

		return state -> {

			if (isAsciiCode('0', state.offset(), state.source())) {

				final int zeroOffset = state.offset() + 1;
				final int baseOffset = zeroOffset + 1;

				if (isAsciiCode('x', zeroOffset, state.source())) {
					return finaliseInt(invalid, hexadecimal, baseOffset, consumeBase16(baseOffset, state.source()), state);
				} else if (isAsciiCode('o', zeroOffset, state.source())) {
					return finaliseInt(invalid, octal, baseOffset, consumeBase(octalBase, baseOffset, state.source()), state);
				} else if (isAsciiCode('b', zeroOffset, state.source())) {
					return finaliseInt(invalid, binary, baseOffset, consumeBase(binaryBase, baseOffset, state.source()), state);
				} else {
					return finaliseFloat(invalid, expecting, decimalInteger, floatingPoint, new int[]{zeroOffset, 0}, state);
				}
			} else {
				return finaliseFloat(invalid, expecting, decimalInteger, floatingPoint,
					consumeBase(decimalBase, state.offset(), state.source()), state);
			}
		};
	}

	static int[] consumeBase(final int base, final int initialOffset, final String string) {

		int offset = initialOffset;
		int result = 0;

		for (; offset < string.length(); offset++) {
			int digit = string.charAt(offset) - '0';
			if (digit < 0 || base <= digit) {
				break;
			}
			result = base * result + digit;
		}

		return new int[]{offset, result};
	}

	private static int[] consumeBase16(final int initialOffset, final String string) {

		final int hexadecimalBase = 16;
		int offset = initialOffset;
		int total = 0;

		for (; offset < string.length(); offset++) {

			final int code = string.charAt(offset);

			if ('0' <= code && code <= '9') {
				total = hexadecimalBase * total + code - '0';
			} else if ('A' <= code && code <= 'F') {
				total = hexadecimalBase * total + code - 55;
			} else if ('a' <= code && code <= 'f') {
				total = hexadecimalBase * total + code - 87;
			} else {
				break;
			}
		}

		return new int[]{offset, total};
	}

	private static <C, X, T> PStep<C, X, T> finaliseInt(
		final X invalid,
		final Result<X, Function<Integer, T>> handler,
		final int startOffset,
		final int[] tuple,
		final State<C> state
	) {

		if (handler.isErr()) {
			return new Bad<>(true, Bag.fromState(state, handler.error()));
		} else {
			final Function<Integer, T> toValue = handler.value();

			if (startOffset == tuple[0]) {
				return new Bad<>((state.offset() < startOffset), Bag.fromState(state, invalid));
			} else {
				return new Good<>(true, toValue.apply(tuple[1]), bumpOffset(tuple[0], state));
			}
		}
	}


	private static <C, X, T> PStep<C, X, T> finaliseFloat(
		final X invalid,
		final X expecting,
		final Result<X, Function<Integer, T>> intSettings,
		final Result<X, Function<Float, T>> floatSettings,
		final int[] intPair,
		final State<C> state) {

		final int intOffset = intPair[0];
		final int floatOffset = consumeDotAndExp(intOffset, state.source());

		if (floatOffset < 0) {
			return new Bad<>(true, Bag.fromInfo(state.row(),
				(state.column() - (floatOffset + state.offset())), invalid, state.context()));
		} else if (state.offset() == floatOffset) {
			return new Bad<>(false, Bag.fromState(state, expecting));
		} else if (intOffset == floatOffset) {
			return finaliseInt(invalid, intSettings, state.offset(), intPair, state);
		} else {
			if (floatSettings.isErr()) {
				return new Bad<>(true, Bag.fromState(state, invalid));
			} else {
				final Function<Float, T> toValue = floatSettings.value();

				try {
					final Float value = Float.valueOf(state.source().substring(state.offset(), floatOffset));

					return new Good<>(true, toValue.apply(value), bumpOffset(floatOffset, state));
				} catch (NumberFormatException e) {
					// TODO - Don't throw return a Bad<>
					return null;
				}
			}
		}
	}

	private static int consumeDotAndExp(final int offset, final String source) {
		if (isAsciiCode('.', offset, source)) {
			return consumeExp(chompBase10((offset + 1), source), source);
		} else {
			return consumeExp(offset, source);
		}
	}

	private static int consumeExp(final int offset, final String source) {
		if (isAsciiCode('.', offset, source) || isAsciiCode('E', offset, source)) {

			int eOffset = offset + 1;
			int expOffset = (isAsciiCode('+', eOffset, source) || isAsciiCode('-', eOffset, source)) ? eOffset + 1 : eOffset;
			int newOffset = chompBase10(expOffset, source);

			if (expOffset == newOffset) {
				return -1 * newOffset;
			} else {
				return newOffset;
			}
		} else {
			return offset;
		}
	}

	private static int chompBase10(final int initialOffset, final String string) {

		int offset = initialOffset;

		for (; offset < string.length(); offset++) {
			int code = string.codePointAt(offset);

			if (code < '0' || '9' < code) {
				return offset;
			}
		}

		return offset;
	}

	public static int[] isSubString(
		final String shorterString,
		final int offset,
		final int row,
		final int col,
		final String longerString
	) {

		final String substring = longerString.substring(offset, offset + shorterString.length());

		if (shorterString.equals(substring)) {

			final int newOffset = offset + substring.length();
			final int newRow = row + ((int) substring.lines().count() - 1);
			final int newColumn =
				((substring.lastIndexOf('\n') == -1)
					? col + substring.length()
					: substring.length() - substring.lastIndexOf('\n'));

			return new int[]{newOffset, newRow, newColumn};
		} else {
			return new int[]{-1, row, col};
		}
	}

	public static int isSubChar(
		final Predicate<Integer> predicate,
		final int offset,
		final String string
	) {

		if (string.length() <= offset) {
			return -1;
		}

		final int codePoint = string.codePointAt(offset);

		if (predicate.test(codePoint)) {
			final String subChar = Character.toString(codePoint);
			return codePoint == '\n' ? -2 : offset + subChar.length();
		} else {
			return -1;
		}
	}

	private static boolean isAsciiCode(final int code, final int offset, final String string) {
		return offset < string.length() && string.codePointAt(offset) == code;
	}

	private static <C> State<C> bumpOffset(final int newOffset, final State<C> s) {
		return new State<>(s.source(), newOffset, s.indent(), s.context(), s.row(), s.column() + (newOffset - s.offset()));
	}
}
