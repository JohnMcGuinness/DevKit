package com.github.simpleparser.common.internal;

public record Located<T>(int row, int column, T context) { }
