package com.github.simpleparser.common.internal;

public record Empty<C, X>() implements Bag<C, X> {
}
