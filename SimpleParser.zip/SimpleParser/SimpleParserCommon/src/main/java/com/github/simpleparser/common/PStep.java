package com.github.simpleparser.common;

public sealed interface PStep<C, X, T> permits Good, Bad { }
