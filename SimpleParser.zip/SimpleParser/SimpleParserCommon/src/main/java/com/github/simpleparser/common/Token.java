package com.github.simpleparser.common;

public record Token<X>(String string, X expecting) { }
