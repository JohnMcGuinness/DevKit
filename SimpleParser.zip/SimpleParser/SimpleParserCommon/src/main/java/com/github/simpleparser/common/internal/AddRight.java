package com.github.simpleparser.common.internal;

import com.github.simpleparser.common.DeadEnd;

public record AddRight<C, X>(Bag<C, X> bag, DeadEnd<C, X> deadend) implements Bag<C, X> { }
