package com.github.simpleparser.common;

import java.io.Serializable;
import java.util.Optional;

public sealed interface Result<X, T> extends Serializable permits Ok, Err {

	X error();

	T value();

	boolean isOk();

	boolean isErr();

	public static <X, T> Result<X, T> fromOptional(X error, Optional<T> value) {
		return value.isPresent() ? new Ok<>(value.get()) : new Err<>(error);
	}
}
