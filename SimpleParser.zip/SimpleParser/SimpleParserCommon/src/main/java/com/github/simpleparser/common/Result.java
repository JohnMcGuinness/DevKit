package com.github.simpleparser.common;

import java.io.Serializable;
import java.util.Optional;

public sealed interface Result<X, T> extends Serializable permits Ok, Err {

	X error();

	T value();

	boolean isOk();

	boolean isErr();

	static <X, T> Result<X, T> ok(T value) {
		return new Ok<>(value);
	}

	static <X, T> Result<X, T> err(X error) {
		return new Err<>(error);
	}

	static <X, T> Result<X, T> fromOptional(X error, Optional<T> value) {
		return value.isPresent() ? new Ok<>(value.get()) : new Err<>(error);
	}
}
