module simpleparser.common {
	requires io.vavr;
	exports com.github.simpleparser.common to simpleparser.basic, simpleparser.advanced;
}