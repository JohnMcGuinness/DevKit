package com.github.simpleparser;

import io.vavr.control.Either;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import static  com.github.simpleparser.Parser.*;

public class BasicParserTest {

	@Test
	public void test1() {

		Either<List<DeadEnd>, Float> p = run(succeed(1f), "abc");

		assertTrue(p.isRight());
		assertEquals(1f, p.get());
	}

	@Test
	public void problemTest() {

		final Problem problem = new ExpectingInt();
		final Either<List<DeadEnd>, Integer> result = run(problem(problem), "abc");

		assertTrue(result.isLeft());

		final List<DeadEnd> deadEnds = result.getLeft();

		assertNotNull(deadEnds);
		assertEquals(1, deadEnds.size());

		final DeadEnd deadend = deadEnds.get(0);

		assertEquals(1, deadend.row());
		assertEquals(1, deadend.column());
		assertEquals(problem, deadend.problem());
	}

	@Test
	public void mapTest() {

		final String expected = "3";
		final Either<List<DeadEnd>, Integer> result
			= run(map(Integer::valueOf, succeed(expected)), "a");

		assertTrue(result.isRight());
		assertEquals(3, result.get());
	}

	@Test
	public void andThenTest() {

		final Either<List<DeadEnd>, Integer> result
			= run(
				andThen(
					s -> succeed(100),
					succeed("1")),
					"2"
			);

		assertTrue(result.isRight());
		assertEquals(100, result.get());
	}
}
