package com.github.simpleparser;

import com.github.simpleparser.common.Result;
import io.vavr.control.Either;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import static  com.github.simpleparser.Parser.*;

public class BasicParserTest {

	@Test
	public void succeedTest() {

		final Result<List<DeadEnd>, Float> result
			= run(
				succeed(1f),
				"abc"
			);

		assertTrue(result.isOk());
		assertEquals(1f, result.value());
	}

	@Test
	public void problemTest() {

		final Problem problem = new ExpectingInt();

		final Result<List<DeadEnd>, Integer> result
			= run(
				problem(problem),
				"abc"
			);

		assertTrue(result.isErr());

		final List<DeadEnd> deadEnds = result.error();

		assertNotNull(deadEnds);
		assertEquals(1, deadEnds.size());

		final DeadEnd deadend = deadEnds.get(0);

		assertEquals(1, deadend.row());
		assertEquals(1, deadend.column());
		assertEquals(problem, deadend.problem());
	}

	@Test
	public void mapTest() {

		final int expected = 3;
		final Result<List<DeadEnd>, Integer> result
			= run(
				map(
					Integer::valueOf,
					succeed(expected)
				),
				"abc"
			);

		assertTrue(result.isOk());
		assertEquals(expected, result.value());
	}

	@Test
	public void andThenTest() {

		final String expected = "12";
		final Result<List<DeadEnd>, String> result
			= run(
				andThen(
					Parser::succeed,
					succeed(expected)
				),
				"abc"
			);

		assertTrue(result.isOk());
		assertEquals(expected, result.value());
	}

	@Test
	public void lazyTest() {

		final String expected = "12";
		final Result<List<DeadEnd>, String> result
			= run(
				lazy(() -> succeed(expected)),
				"abc"
			);

		assertTrue(result.isOk());
		assertEquals(expected, result.value());
	}

	@Test
	public void tokenTest() {

		final Result<List<DeadEnd>, Void> result
			= run(
				token("let"),
				"letter"
			);

		assertTrue(result.isOk());
		assertNull(result.value());
	}
}
