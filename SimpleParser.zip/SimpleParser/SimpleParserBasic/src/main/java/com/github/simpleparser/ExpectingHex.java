package com.github.simpleparser;

public record ExpectingHex() implements Problem { }
