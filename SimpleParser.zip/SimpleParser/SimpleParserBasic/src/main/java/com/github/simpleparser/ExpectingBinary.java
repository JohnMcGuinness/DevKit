package com.github.simpleparser;

public record ExpectingBinary() implements Problem { }
