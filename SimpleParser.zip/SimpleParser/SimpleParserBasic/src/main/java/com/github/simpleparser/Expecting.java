package com.github.simpleparser;

public record Expecting(String message) implements Problem {
}
