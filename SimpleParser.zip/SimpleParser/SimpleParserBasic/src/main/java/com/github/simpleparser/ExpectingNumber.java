package com.github.simpleparser;

public record ExpectingNumber() implements Problem { }

