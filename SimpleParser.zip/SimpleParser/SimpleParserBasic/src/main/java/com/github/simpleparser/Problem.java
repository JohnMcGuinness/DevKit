package com.github.simpleparser;

public sealed interface Problem permits Expecting, ExpectingInt { }
