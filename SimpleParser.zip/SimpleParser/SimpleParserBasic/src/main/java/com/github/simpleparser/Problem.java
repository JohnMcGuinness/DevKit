package com.github.simpleparser;

public sealed interface Problem
		permits
		Expecting,
		ExpectingInt,
		ExpectingNumber,
		ExpectingHex,
		ExpectingOctal,
		ExpectingBinary,
		ExpectingFloat,
		ExpectingEnd,
		ExpectingVariable
{

	Problem EXPECTING_INT = new ExpectingInt();

	Problem EXPECTING_HEX = new ExpectingHex();

	Problem EXPECTING_OCTAL = new ExpectingOctal();

	Problem EXPECTING_BINARY = new ExpectingBinary();

	Problem EXPECTING_FLOAT = new ExpectingFloat();

	Problem EXPECTING_NUMBER = new ExpectingNumber();

	Problem EXPECTING_END = new ExpectingEnd();

	Problem EXPECTING_VARIABLE = new ExpectingVariable();

	static Problem expecting(final String expecting) {
		return new Expecting(expecting);
	}
}
