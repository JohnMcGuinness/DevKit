package com.github.simpleparser;

public sealed interface Problem permits Expecting, ExpectingInt, ExpectingNumber, ExpectingHex, ExpectingOctal, ExpectingBinary, ExpectingFloat {

	Problem EXPECTING_INT = new ExpectingInt();

	Problem EXPECTING_HEX = new ExpectingHex();

	Problem EXPECTING_OCTAL = new ExpectingOctal();

	Problem EXPECTING_BINARY = new ExpectingBinary();

	Problem EXPECTING_FLOAT = new ExpectingFloat();

	Problem EXPECTING_NUMBER = new ExpectingNumber();

	static Problem expecting(final String expecting) {
		return new Expecting(expecting);
	}

	static Problem expectingInt() {
		return EXPECTING_INT;
	}

	static Problem expectingNumber() {
		return EXPECTING_NUMBER;
	}
}
