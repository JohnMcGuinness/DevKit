package com.github.simpleparser;

import com.github.simpleparser.common.AbstractParser;
import com.github.simpleparser.common.PStep;
import com.github.simpleparser.common.State;
import com.github.simpleparser.common.ParserImpl;
import io.vavr.control.Either;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public final class Parser<T> extends AbstractParser<Void, Problem, T> {

	private Parser(final Function<State<Void>, PStep<Void, Problem, T>> parse) {
		super(parse);
	}

	public static <T> Either<List<DeadEnd>, T> run(final Parser<T> parser, String source) {

		final Either<List<com.github.simpleparser.common.DeadEnd<Void, Problem>>, T> result = ParserImpl.run(parser, source);

		if (result instanceof Either.Right<?, T> right) {
			return Either.right(right.get());
		} else {
			final List<com.github.simpleparser.common.DeadEnd<Void, Problem>> problems = result.getLeft();

			final List<DeadEnd> deadEnds = problems
				.stream()
				.map(Parser::problemToDeadEnd)
				.collect(Collectors.toList());

			return Either.left(deadEnds);
		}
	}

	private static DeadEnd problemToDeadEnd(final com.github.simpleparser.common.DeadEnd<Void, Problem> problem) {
		return new DeadEnd(problem.row(), problem.column(), problem.problem());
	}

	public static <T> Parser<T> succeed(final T value) {
		return  new Parser<>(ParserImpl.succeedF(value));
	}

	public static <T> Parser<T> problem(final Problem problem) {
		return new Parser<>(ParserImpl.problemF(problem));
	}

	public static <T, R> Parser<R> map(final Function<T, R> f, final Parser<T> parser) {
		return new Parser<>(ParserImpl.mapF(f, parser));
	}

	public static <T, R> Parser<R> andThen(final Function<T, Parser<R>> callback, final Parser<T> parser) {
		return new Parser<>(ParserImpl.andThenF(callback, parser));
	}
}