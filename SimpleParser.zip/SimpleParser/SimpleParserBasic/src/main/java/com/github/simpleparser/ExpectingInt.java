package com.github.simpleparser;

public record ExpectingInt() implements Problem { }
