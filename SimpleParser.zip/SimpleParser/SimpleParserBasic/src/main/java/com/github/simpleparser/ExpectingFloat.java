package com.github.simpleparser;

public record ExpectingFloat() implements Problem { }
