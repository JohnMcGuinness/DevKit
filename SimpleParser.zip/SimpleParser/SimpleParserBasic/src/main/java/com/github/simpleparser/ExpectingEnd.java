package com.github.simpleparser;

public record ExpectingEnd() implements Problem { }
