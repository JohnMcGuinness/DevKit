package com.github.simpleparser;

public record DeadEnd(int row, int column, Problem problem) { }

