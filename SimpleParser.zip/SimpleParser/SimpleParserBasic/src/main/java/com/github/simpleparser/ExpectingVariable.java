package com.github.simpleparser;

public record ExpectingVariable() implements Problem {
}
