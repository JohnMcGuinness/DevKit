package com.github.simpleparser;

public class Token {
}
