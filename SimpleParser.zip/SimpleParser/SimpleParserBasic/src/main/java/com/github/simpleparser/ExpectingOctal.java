package com.github.simpleparser;

public record ExpectingOctal() implements Problem { }
