module simpleparser.basic {
	requires simpleparser.common;
	requires io.vavr;
	exports com.github.simpleparser;
}