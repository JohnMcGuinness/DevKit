package au.gov.immi.uitest.wc.selector;


public class TableHeaderCellSelector //extends ComponentSelector<TableHeader> 
{
//	@Override
//	public List<Cell> filter(List<Cell> list) 
//	{
//		return list;
//	}
//
//	@Override
//	public String rootElementCssSelector() 
//	{
//		return "th";
//	}
//
//	@Override
//	public Class<Cell> getComponentClass() 
//	{
//		return Cell.class;
//	}

}
