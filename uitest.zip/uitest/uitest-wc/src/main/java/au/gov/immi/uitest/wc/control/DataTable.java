package au.gov.immi.uitest.wc.control;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.internal.WrapsDriver;

import uitest.component.Component;
import uitest.component.Parent;
import uitest.core.EnclosedComponentSelector;
import au.gov.immi.uitest.wc.selector.DataTableInstanceSelector;
import au.gov.immi.uitest.wc.selector.DataTableSelector;

public class DataTable extends Component
{
	public enum SelectMode
	{
		NONE,
		SINGLE,
		MULTIPLE
	}
	
	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}

	public String getCaption() 
	{
//		final WebElement caption = getRoot().findElement(By.cssSelector("caption > span.off"));
		
		System.out.println("Root tag: " + getRoot().getTagName());
		
		System.out.println("Table tag: " + getRoot().findElement(By.cssSelector("table")).getTagName());
		
		System.out.println("Caption tag: " + getRoot().findElement(By.cssSelector("caption")).getTagName());
		
		System.out.println("HTML: " + (String)((JavascriptExecutor)((WrapsDriver)getRoot()).getWrappedDriver()).executeScript("return arguments[0].outerHTML;", getRoot()));
		
//		System.out.println("Caption tag name: " + (String)((JavascriptExecutor)((WrapsDriver)getRoot()).getWrappedDriver()).executeScript("return arguments[0].innerText;", caption));

//		System.out.println("Caption: " + caption.getText());
		
		return "";
	}
	
	public void selectRowByCellValue(final String columnName, final String cellValue)
	{
		System.out.println("Rows found: " + getRows().size());
		
		for(TableRow row : getRows())
		{
			System.out.println("Row: " + row.getRowIndex());
			
			if(row.getCellText(columnName).trim().equalsIgnoreCase(cellValue.trim()))
			{
				row.select();
				break;
			}
		}
	}
	
	public void selectRowByRowIndex(int index)
	{
		getRows().get(index - 1).select();
	}

	public static DataTableSelector with() 
	{
		return new DataTableSelector();
	}
	
	public static DataTableInstanceSelector instance()
	{
		return new DataTableInstanceSelector(0);
	}
	
	public static DataTableInstanceSelector instance(final int index)
	{
		return new DataTableInstanceSelector(index);
	}
	
	private List<TableRow> getRows()
	{
		return Parent.fromComponent(this).findAll(DataTable.rowsEnclosedBy(this));
	}
	
	private static TableRowSelector rowsEnclosedBy(DataTable enclosingDataTable) 
	{
		return new TableRowSelector(enclosingDataTable);
	}

	private TableHead tableHead()
	{
		return Parent.fromComponent(this).find(DataTable.headFor(this));
	}
	
	private String getColumnHeadingForData(final TableData cell)
	{
		return tableHead().getLabelFor(cell);
	}
	
	private static TableHeadSelector headFor(DataTable enclosingDataTable) 
	{
		return new TableHeadSelector(enclosingDataTable);
	}
	
	private WebElement getTableBody()
	{
		return getRoot().findElement(By.cssSelector("table > tbody"));
	}
	
	private class TableHead extends Component
	{
		@Override
		public boolean isDisplayed() 
		{
			return false;
		}
		
		public List<TableHeader> getHeaders()
		{
			return Collections.emptyList();//Parent.fromComponent(this).findAll(TableHeader.instancesInTableHeader());
		}

		public String getLabelFor(Cell cell) 
		{
			final String headerId = cell.getId();
			
			if(headerId == null || headerId.isEmpty())
			{
				return null;
			}
			
			for(TableHeader header : getHeaders())
			{
				if(headerId.equalsIgnoreCase(header.getId()))
				{
					return header.find(DecoratedLabel.instance()).getBodyCell().getText();
				}
			}
			
//			for(Cell header : getHeaders())
//			{
//				String id = header.getId();
//				
//				if(!id.isEmpty() &&  id.equals(cell.getHeaderId()))
//				{
//					return header.find(DecoratedLabel.instance()).getBodyCell().getText();
//				}
//			}
			
			return "";
		}
	}
	
	private class TableHeader extends Cell
	{
		
	}
	
	private class TableBody extends Parent
	{
		public boolean isRadioGroup()
		{
			return "radiogroup".equals(getAttributeOfRootNamed("role"));
		}
		
		public List<TableRow> getRows()
		{
			if(isRadioGroup())
			{
				
			}
			
//			findAll(TableRow.instancesIn(this));
			
			return Collections.emptyList();
		}
	}
	
	private class TableData extends Cell
	{
		
	}
	
	private class TableRow extends Component
	{
		private WebElement colHeadings;
		private Map<String,String> headings = new HashMap<String, String>();

		public  TableRowSelector instancesIn(/*final DataTable tableBody*/)
		{
			return null;//new TableRowSelector(tableBody);
		}
		
		public void select()
		{
			if(isSelectable())
			{
				getRowSelector().click();
			}
//			getRoot().click();
		}

		public String getRowIndex() 
		{
			return getAttributeOfRootNamed("data-rowindex");
		}

		public boolean isSelectable()
		{
			try
			{
				getRowSelector();
				return true;
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				return false;
			}
		}
		
		private WebElement getRowSelector()
		{
			WebElement el = getRoot().findElement(By.cssSelector("td.wc_wdt_sel_wrapper"));
			
			System.out.println(el.toString() + " class: " + el.getAttribute("class") + ", headers: " + el.getAttribute("headers"));
			
			return el;
		}
		
		public String getCellText(String columnHeading)
		{
			DataTable enclosingTable = DataTable.this;
			
			DataTable.TableHead header = enclosingTable.tableHead();

			System.out.println("Looking header with text:" + columnHeading);

			for(Cell cell: getCells())
			{
				System.out.println("Found header with text:" + header.getLabelFor(cell));

				if(header.getLabelFor(cell).equalsIgnoreCase(columnHeading))
				{
					return cell.find(DecoratedLabel.instance()).getBodyCell().getText();
				}
			}
			
			return null;
		}
		
//		private void initHeadings()
//		{
//			DataTable enclosingTable = DataTable.this;
//			
//			Header header = enclosingTable.getTableHeader();
//			
//			header.getLabelForColumnHeaderWithId(headerId);
//			
//			List<WebElement> colHeaders = colHeadings.findElements(By.cssSelector("th"));
//			
//			for(WebElement colHeader : colHeaders)
//			{
//				String heading = colHeader.getText().trim();
//				String headingId = colHeader.getAttribute("id");
//				
//				headings.put(heading, headingId);
//			}
//		}

		public boolean isSelected()
		{
			return Boolean.parseBoolean(getRoot().getAttribute("aria-selected"));
		}
		
		public int rowIndex()
		{
			return Integer.parseInt(getAttributeOfRootNamed("data-rowindex"));
		}

		public List<Cell> getCells()
		{
			return Parent.fromComponent(this).findAll(Cell.instancesInTableRow());
		}
		
		@Override
		public boolean isDisplayed() 
		{
			return false;
		}
	}
	
	private static class TableHeadSelector extends EnclosedComponentSelector<DataTable, DataTable.TableHead>
	{
		private DataTable enclosingDataTable;
		
		public TableHeadSelector(DataTable enclosingDataTable)
		{
			this.enclosingDataTable = enclosingDataTable;
		}

		@Override
		public List<TableHead> filter(List<TableHead> list) 
		{
			return list;
		}

		@Override
		public String rootElementCssSelector() 
		{
			return "thead > tr";
		}

		@Override
		public Class<TableHead> getComponentClass() 
		{
			return DataTable.TableHead.class;
		}

		@Override
		public DataTable getEnclosingComponent() 
		{
			return this.enclosingDataTable;
		}
	}
	
	private static class TableRowSelector extends EnclosedComponentSelector<DataTable, DataTable.TableRow>
	{
		private DataTable enclosingDataTable;

		public TableRowSelector(DataTable enclosingDataTable)
		{
			this.enclosingDataTable = enclosingDataTable;
		}
		
		@Override
		public List<TableRow> filter(List<TableRow> list) 
		{
			// Return them all.
			return list;
		}

		@Override
		public String rootElementCssSelector() 
		{
			return "tbody > tr[data-rowindex]";
		}

		@Override
		public Class<DataTable.TableRow> getComponentClass() 
		{
			return DataTable.TableRow.class;
		}

		@Override
		public DataTable getEnclosingComponent() 
		{
			return enclosingDataTable;
		}
	}
}
