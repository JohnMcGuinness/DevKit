package au.gov.immi.uitest.wc.control;

import uitest.component.Parent;
import au.gov.immi.uitest.wc.selector.TableHeaderCellSelector;
import au.gov.immi.uitest.wc.selector.TableRowCellSelector;

public class Cell extends Parent 
{
	public static TableRowCellSelector instancesInTableRow() 
	{
		return new TableRowCellSelector();
	}

	public static TableHeaderCellSelector instancesInTableHeader() 
	{
		return new TableHeaderCellSelector();
	}
	
	protected String getHeaderId()
	{
		System.out.println("Getting Header Id");
		return getAttributeOfRootNamed("headers");
	}

	public String getText() 
	{
		return getRoot().getText();
	}

	public String getId() 
	{
		System.out.println("Getting Id");
		return getAttributeOfRootNamed("id");
	}
}
