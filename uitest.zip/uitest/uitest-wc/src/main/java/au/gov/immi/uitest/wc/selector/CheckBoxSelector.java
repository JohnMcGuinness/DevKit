package au.gov.immi.uitest.wc.selector;

import java.util.ArrayList;
import java.util.List;

import uitest.core.ComponentSelector;
import au.gov.immi.uitest.wc.control.CheckBox;

public class CheckBoxSelector extends ComponentSelector<CheckBox>
{
	private String label;
	
	@Override
	public List<CheckBox> filter(List<CheckBox> candidates) 
	{
		final List<CheckBox> matches = new ArrayList<>();
		
		for(CheckBox candidate : candidates)
		{
			if(label != null && label.equals(candidate.getLabel().getText()))
			{
				matches.add(candidate);
			}
		}
		
		return matches;
	}
	
	public CheckBoxSelector label(String label) 
	{
		this.label = label;
		return this;
	}
	
	@Override
	public String rootElementCssSelector() 
	{
		return "input[type=\"checkbox\"]";
	}

	@Override
	public Class<CheckBox> getComponentClass() 
	{
		return CheckBox.class;
	}

}
