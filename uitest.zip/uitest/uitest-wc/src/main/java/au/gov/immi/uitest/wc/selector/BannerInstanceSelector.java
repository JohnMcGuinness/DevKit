package au.gov.immi.uitest.wc.selector;

import java.util.List;

import uitest.core.ComponentSelector;
import au.gov.immi.uitest.wc.control.Banner;

public class BannerInstanceSelector extends ComponentSelector<Banner>
{
	@Override
	public List<Banner> filter(List<Banner> list) 
	{
		return list;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "*[role=\"banner\"]";
	}

	@Override
	public Class<Banner> getComponentClass() 
	{
		return Banner.class;
	}
}
