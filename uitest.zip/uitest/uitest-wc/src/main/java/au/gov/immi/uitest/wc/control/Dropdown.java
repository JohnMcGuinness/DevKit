package au.gov.immi.uitest.wc.control;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import uitest.component.CanBeReadOnly;
import uitest.component.Component;
import uitest.core.ComponentSearchContext;
import au.gov.immi.uitest.wc.selector.DropdownSelector;

public class Dropdown extends Component implements CanBeReadOnly
{
	final Logger log = Logger.getLogger(getClass().getName());

	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}

	public static DropdownSelector with() 
	{
		return new DropdownSelector();
	}

	public void enter(String text) 
	{
		getRoot().sendKeys(text);
	}
	
	public Label getLabel()
	{
		final ComponentSearchContext context = getContext();
		final String id = getRoot().getAttribute("id");
		
//		log.info(context == null ?  "context is null" : "context is not null");
		
		return context.find(Label.forComponent(id));
	}

	public void select(String option) 
	{
//		if(options().contains(option))
		try{
			(new Select(getRoot())).selectByVisibleText(option);
		}
		catch (Exception e)
		{
//			throw new RuntimeException(option + " is not a valid option.");
			throw new RuntimeException(e);
		}
	}
	
	public List<String> options()
	{
		final List<String> options = new ArrayList<>();
		
		List<WebElement> optionElements = getRoot().findElements(By.tagName("option"));
		
		for(WebElement optionElement : optionElements)
		{
			options.add(optionElement.getText());
		}
		
		return options;
	}

	@Override
	public boolean isReadOnly() 
	{
		return false;
	}
}
