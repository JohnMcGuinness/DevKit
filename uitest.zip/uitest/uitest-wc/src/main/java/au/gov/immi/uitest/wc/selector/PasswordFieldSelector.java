package au.gov.immi.uitest.wc.selector;

import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.PasswordField;

public class PasswordFieldSelector extends ComponentSelector<PasswordField> 
{
	private String label;
	private String id;
	
	@Override
	public List<PasswordField> filter(List<PasswordField> list) 
	{
		return list;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "input[type=\"password\"]";
	}

	@Override
	public Class<PasswordField> getComponentClass() 
	{
		return PasswordField.class;
	}

	public PasswordFieldSelector label(String label) 
	{
		this.label = label;
		return this;
	}
	
	public PasswordFieldSelector id(String id) 
	{
		this.id = id;
		return this;
	}
}
