package au.gov.immi.uitest.wc.control;

import uitest.component.Parent;
import au.gov.immi.uitest.wc.selector.BannerInstanceSelector;

public class Banner extends Parent 
{
	public static BannerInstanceSelector instance()
	{
		return new BannerInstanceSelector();
	}
}
