package au.gov.immi.uitest.wc.selector;

import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.MenuItem;

public class MenuItemSelector extends ComponentSelector<MenuItem> 
{
	@Override
	public List<MenuItem> filter(List<MenuItem> list) 
	{
		return list;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "*[role=\"menuitem\"]";
	}

	@Override
	public Class<MenuItem> getComponentClass() 
	{
		return MenuItem.class;
	}
}
