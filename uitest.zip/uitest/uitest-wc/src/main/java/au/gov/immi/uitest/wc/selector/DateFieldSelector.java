package au.gov.immi.uitest.wc.selector;

import java.util.ArrayList;
import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.DateField;

public class DateFieldSelector extends ComponentSelector<DateField> 
{
	private String label;

	@Override
	public List<DateField> filter(List<DateField> candidates) 
	{
		final List<DateField> matches = new ArrayList<>();
		
		for(DateField candidate : candidates)
		{
			if(label != null && label.equals(candidate.getLabel().getText()))
			{
				matches.add(candidate);
			}
		}
		
		return matches;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "input[type=\"text\"]";
	}

	@Override
	public Class<DateField> getComponentClass() 
	{
		return DateField.class;
	}

	public DateFieldSelector label(String label) 
	{
		this.label = label;
		return this;
	}
	
	@Override
	public String toString() 
	{
		final StringBuilder sb = new StringBuilder("Date field");
		
		if(label != null)
		{
			sb.append(" with label [\"" + label + "\"]");
		}
		
		return sb.toString();
	}
}
