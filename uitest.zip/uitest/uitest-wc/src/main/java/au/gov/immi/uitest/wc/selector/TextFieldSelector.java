package au.gov.immi.uitest.wc.selector;

import java.util.ArrayList;
import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.TextField;

public class TextFieldSelector extends ComponentSelector<TextField> {

    private String label;
    private String id;

    @Override
    public List<TextField> filter(List<TextField> candidates) {
        final List<TextField> matches = new ArrayList<>();

        for (TextField candidate : candidates) {
            if (label != null && label.equals(candidate.getLabel().getText())) {
                matches.add(candidate);
            }

            if (id != null && id.equals(candidate.getId())) {
                matches.add(candidate);
            }
        }

        return matches;
    }

    @Override
    public String rootElementCssSelector() {
        return ".wc-textfield";
    }

    @Override
    public Class<TextField> getComponentClass() {
        return TextField.class;
    }

    public TextFieldSelector label(String label) {
        this.label = label;
        return this;
    }

    public TextFieldSelector id(String id) {
        this.id = id;
        return this;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Text field");

        if (label != null) {
            sb.append(" with label [\"" + label + "\"]");
        }

        if (id != null) {
            sb.append(" with id [\"" + id + "\"]");
        }

        return sb.toString();
    }
}
