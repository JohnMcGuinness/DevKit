package au.gov.immi.uitest.wc.control;

import java.util.logging.Logger;

import uitest.component.CanBeReadOnly;
import uitest.component.Component;
import uitest.core.ComponentSearchContext;
import au.gov.immi.uitest.wc.selector.TextFieldSelector;
import java.util.Optional;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class TextField extends Component implements CanBeReadOnly {

    final Logger log = Logger.getLogger(getClass().getName());

    @Override
    public boolean isDisplayed() {
        return getRoot().isDisplayed();
    }

    public static TextFieldSelector with() {
        return new TextFieldSelector();
    }

    public void enter(String text) {
        getRoot().sendKeys(text);
    }

    public String getText() {
        return getRoot().getText();
    }

    public Label getLabel() {
        final ComponentSearchContext context = getContext();
        final String id = getRoot().findElement(By.tagName("input")).getAttribute("id");

//		log.info(context == null ?  "context is null" : "context is not null");
        return context.find(Label.forComponent(id));
    }

    public String getId() {
        return getRoot().getAttribute("id");
    }

    public Optional<Integer> maxLength() {

        final String value = isReadOnly() 
            ? null
            : getRoot().findElement(By.tagName("input")).getAttribute("maxlength");

        return Optional.ofNullable(value).map(i -> Integer.parseInt(i));
    }
    
    @Override
    public boolean isReadOnly() {
        return "span".equalsIgnoreCase(getRoot().getTagName());
    }
}
