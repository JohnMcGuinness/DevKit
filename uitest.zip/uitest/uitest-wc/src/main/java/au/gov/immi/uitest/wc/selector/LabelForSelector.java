package au.gov.immi.uitest.wc.selector;

import java.util.ArrayList;
import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.Label;

public class LabelForSelector extends ComponentSelector<Label> {

    private final String id;

    public LabelForSelector(final String id) {
        this.id = id;
    }

    @Override
    public List<Label> filter(List<Label> candidates) {
        final List<Label> matches = new ArrayList<>();

        for (Label candidate : candidates) {
            if (candidate.id().equals(id)) {
                matches.add(candidate);
            }
        }

        return candidates;
    }

    @Override
    public String rootElementCssSelector() {
//        return "label[for=\"" + id + "\"], span[class~=\"wc_lbl_dummy\"][data-for=\"" + id + "\"], span[class~=\"wc_lbl_dummy\"][data-rofor=\"" + id + "\"]";
        return "label[for=\"" + id + "\"]";
    }

    @Override
    public Class<Label> getComponentClass() {
        return Label.class;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Label");

        if (id != null) {
            sb.append(" for [\"" + id + "\"]");
        }

        return sb.toString();
    }
}
