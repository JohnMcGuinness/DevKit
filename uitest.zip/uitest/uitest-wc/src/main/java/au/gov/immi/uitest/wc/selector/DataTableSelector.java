package au.gov.immi.uitest.wc.selector;

import java.util.ArrayList;
import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.DataTable;

public class DataTableSelector extends ComponentSelector<DataTable> 
{
	private String caption;
	
	@Override
	public List<DataTable> filter(List<DataTable> candidates) 
	{
		final List<DataTable> matches = new ArrayList<>();
		
		for(DataTable candidate : candidates)
		{
			System.out.println("Caption: " + candidate.getCaption());
			if(caption != null && caption.equals(candidate.getCaption()))
			{
				matches.add(candidate);
			}
		}
		
		return matches;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "div[class=\"table-wrapper\"]";
	}

	@Override
	public Class<DataTable> getComponentClass() 
	{
		return DataTable.class;
	}
	
	public DataTableSelector caption(final String caption)
	{
		this.caption = caption;
		return this;
	}
	
	@Override
	public String toString() 
	{
		final StringBuilder sb = new StringBuilder("DataTable");
		
		if(this.caption != null)
		{
			sb.append(" with caption [\"" + caption + "\"]");
		}
		
		return sb.toString();
	}
}
