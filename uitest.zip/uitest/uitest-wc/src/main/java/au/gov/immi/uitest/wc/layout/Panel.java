package au.gov.immi.uitest.wc.layout;

import uitest.component.AbstractParent;

public class Panel extends AbstractParent
{
	@Override
	public boolean isDisplayed() 
	{
		return false;
	}
}
