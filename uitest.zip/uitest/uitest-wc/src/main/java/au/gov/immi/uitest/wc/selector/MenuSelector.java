package au.gov.immi.uitest.wc.selector;

import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.Menu;

public class MenuSelector extends ComponentSelector<Menu> 
{
	private final String menuItemId;

	public MenuSelector(final String menuItemId)
	{
		this.menuItemId = menuItemId;
	}

	@Override
	public List<Menu> filter(List<Menu> list) 
	{
		return null;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "menu[aria-labelledby=\" + menuItemId + \"]";
	}

	@Override
	public Class<Menu> getComponentClass()
	{
		return Menu.class;
	}
}
