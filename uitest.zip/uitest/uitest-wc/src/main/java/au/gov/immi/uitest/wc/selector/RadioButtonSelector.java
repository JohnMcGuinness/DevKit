package au.gov.immi.uitest.wc.selector;

import java.util.ArrayList;
import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.RadioButton;

public class RadioButtonSelector  extends ComponentSelector<RadioButton>
{
	private String label;
	
	@Override
	public List<RadioButton> filter(List<RadioButton> candidates) 
	{
		final List<RadioButton> matches = new ArrayList<>();
		
		for(RadioButton candidate : candidates)
		{
			if(label != null && label.equals(candidate.getLabel().getText()))
			{
				matches.add(candidate);
			}
		}
		
		return matches;
	}
	public RadioButtonSelector label(String label) 
	{
		this.label = label;
		return this;
	}
	
	@Override
	public String rootElementCssSelector() 
	{
		return "input[type=\"radio\"]";
	}

	@Override
	public Class<RadioButton> getComponentClass() 
	{
		return RadioButton.class;
	}
	
	@Override
	public String toString() 
	{
		final StringBuilder sb = new StringBuilder("Radio button");
		
		if(this.label != null)
		{
			sb.append(" with label [\"" + label + "\"]");
		}
		
		return sb.toString();
	}


}
