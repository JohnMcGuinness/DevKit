package au.gov.immi.uitest.wc.control;

import uitest.component.Component;
import au.gov.immi.uitest.wc.selector.PasswordFieldSelector;

public class PasswordField extends Component 
{
	@Override
	public boolean isDisplayed() 
	{
		return false;
	}

	public static PasswordFieldSelector with() 
	{
		return new PasswordFieldSelector();
	}

	public void enter(String text) 
	{
		getRoot().sendKeys(text);
	}
}
