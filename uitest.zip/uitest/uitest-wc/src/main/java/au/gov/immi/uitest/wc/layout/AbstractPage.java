package au.gov.immi.uitest.wc.layout;

import uitest.component.ElementComponent;
import uitest.core.browser.Browser;

public abstract class AbstractPage 
{
	private Browser browser;

	public AbstractPage(final Browser browser)
	{
		this.browser = browser;
	}
	
	public void sync()
	{
		String readyState = getReadyState();
		
		System.out.println("readyState: " + readyState);
		
		while(!readyState.equals("complete"))
		{
			System.out.println("readyState: " + readyState);
			readyState = getReadyState();
		}
		
		ElementComponent body = browser.find(ElementComponent.with().tag("body"));
		
		final long start = System.currentTimeMillis();
		
		while(body.getBooleanAttribute("data-wcajax"))
		{
			long time = (System.currentTimeMillis() - start);
			System.out.println("Waiting...(" + time  + "ms)" );
			
			if(time > 200000)
			{
				break;
			}
		}
		
		while(body.getBooleanAttribute("data-wctimers"))
		{
			long time = (System.currentTimeMillis() - start);
			System.out.println("Waiting...(" + time  + "ms)" );
			
			if(time > 200000)
			{
				break;
			}
		}
	}
	
	protected Browser browser()
	{
		return browser;
	}
	
	private String getReadyState()
	{
		return (String) browser.executeScript("return document.readyState");
	}
}
