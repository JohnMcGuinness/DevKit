package au.gov.immi.uitest.wc.control;

import java.util.List;

import uitest.component.Component;
import au.gov.immi.uitest.wc.selector.MenuBarSelector;


/**
 */
public class MenuBar extends Component
{
	private static final String TREE_MENU_WRAPPER = "menu.bar-menu";
	private static final String MENU_ITEM_BUTTON_CSS_SELECTOR = "button[role=menuitem]";
	private static final String EXPANDABLE_MENU_ITEM_CSS_SELECTOR = "div[role=menuitem]";
	
	private static final String SUBMENU_WRAPPER_CSS_SELECTOR = "menu[role=group]";
	private static final String SUBMENU_EXPANDER_CSS_SELECTOR = "button.opener";
	private static final String MENU_ITEM_EXPANDED_ATTRIBUTE = "aria-expanded";
	
//	protected MenuBar(WebElement element, NodeSearchContext context, NodeFinder finder)
//    {
//        super(element, context, finder);
//    }
//
//	public static class Finder extends NodeFinder
//    {
//		private String firstMenuLabel;
//        private List<String> menuLabels = new ArrayList<String>();
//        
//        @Override
//        public List<MenuBar> findAll(ComponentSearchContext base)
//        {
//            List<MenuBar> candidates = new ArrayList<MenuBar>(); 
//            
//            List<MenuBar> allInstances = findInstances(base);
//            
//            for(MenuBar menuBar : allInstances)
//            {
//                if(null != firstMenuLabel)
//                {
//                    if(menuBar.firstMenu().equalsIgnoreCase(firstMenuLabel))
//                    {
//                        candidates.add(menuBar);
//                    }
//                }
//            }
//            
//            if(!menuLabels.isEmpty())
//            {
//            	List<MenuBar> menubars = new ArrayList<MenuBar>(candidates.isEmpty() ? allInstances : candidates);
//            	
//                for(MenuBar menuBar : menubars)
//                {
//                    List<String> actualMenuLabels = menuBar.items();
//                    
//                    for(String menuLabel : menuLabels)
//                    {
//                        if(actualMenuLabels.contains(menuLabel))
//                        {
//                            candidates.add(menuBar);
//                        }
//                        else
//                        {
//                            candidates.remove(menuBar);
//                            break;
//                        }
//                    }
//                }
//            }
//
//            return candidates;
//        }
//        
//        public MenuBar.Finder firstMenu(String firstMenuItem)
//        {
//            menuLabels.add(firstMenuItem);
//            this.firstMenuLabel = firstMenuItem;
//            return this;
//        }
//        
//        public MenuBar.Finder menu(String menuItem)
//        {
//            menuLabels.add(menuItem);
//            return this;
//        }
//        
//        public MenuBar.Finder menus(String... menuItems)
//        {
//            this.menuLabels.addAll(Arrays.asList(menuItems));
//            return this;
//        }
//        
//        private List<MenuBar> findInstances(ComponentSearchContext context)
//        {
//            String cssSelector = TREE_MENU_WRAPPER;
//
//            List<WebElement> menuElements = context.getWrappedSearchContext().findElements(By.cssSelector(cssSelector));
//            
//            List<MenuBar> menus = new ArrayList<MenuBar>();
//            
//            for(WebElement menuElement : menuElements)
//            {
//                menus.add(new MenuBar(menuElement, context, this));
//            }
//            return menus;
//        }
//    }

//	public String firstMenu() 
//	{
//		return items().get(0);
//	}

	public List<MenuItem> items() 
	{
//		List<String> menuLabels = new ArrayList<String>();
//		
////		List<String> menuItemSelectors = Arrays.asList("menu.tree-menu > button","menu.tree-menu > menu.item > button");
//		List<String> menuItemSelectors = Arrays.asList("menu.bar-menu > *[role=menuitem]");
//		
//		List<WebElement> menuItemElements = new ArrayList<WebElement>();
//		
//		for(String menuItemSelector : menuItemSelectors)
//		{
//			menuItemElements.addAll(getRoot().findElements(By.cssSelector(menuItemSelector)));
//		}
//		
//		for(WebElement menuItemElement : menuItemElements)
//		{
//			menuLabels.add(menuItemElement.getText());
//		}

		return  getContext().findAll(MenuItem.instances());
	}
	
	public void select(String... items)
	{
//		List<String> menuNode = Arrays.asList(items);
//		
//		WebElement context = getRoot();
//		
//		List<WebElement> submitters = Collections.emptyList();
//		
//		for(String menuText : menuNode)
//		{
//			if(menuNode.indexOf(menuText) == (menuNode.size() - 1))
//			{
//				submitters = context.findElements(By.cssSelector(MENU_ITEM_BUTTON_CSS_SELECTOR));
//
//				for(WebElement submitter : submitters)
//				{
//					if(menuText.equalsIgnoreCase(submitter.getText()))
//					{
//						submitter.click();
//						break;
//					}
//				}
//			}
//			else
//			{
//				List<WebElement> menuItems = context.findElements(By.cssSelector(EXPANDABLE_MENU_ITEM_CSS_SELECTOR));
//				
//				{
//					for(WebElement menuItem : menuItems)
//					{
//						WebElement subMenuExpander = menuItem.findElement(By.cssSelector(SUBMENU_EXPANDER_CSS_SELECTOR));
//						if(menuText.equalsIgnoreCase(subMenuExpander.getText()))
//						{
//							if(menuItem.getAttribute(MENU_ITEM_EXPANDED_ATTRIBUTE ).contains("true")) break;
//							
//							subMenuExpander.click();
//							//Need to repeat this for some reason in IE.
//							if(menuItem.getAttribute(MENU_ITEM_EXPANDED_ATTRIBUTE).contains("true")) break;
//							
//							subMenuExpander.click();
//							
//							context = menuItem.findElement(By.cssSelector(SUBMENU_WRAPPER_CSS_SELECTOR));
//							break;
//						}
//					}
//				}
//			}
//		}
		
		if(items.length == 1)
		{
			List<MenuItem> menuItems = items();
			
			for(MenuItem menuItem : menuItems)
			{
				if(items[0].equals(menuItem.label()))
				{
					menuItem.click();
				}
			}
		}
		else
		{
			
		}
	}

	public static MenuBarSelector with() 
	{
		return new MenuBarSelector();
	}

	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}
}
