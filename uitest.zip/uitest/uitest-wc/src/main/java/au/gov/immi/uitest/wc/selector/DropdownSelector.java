package au.gov.immi.uitest.wc.selector;

import java.util.ArrayList;
import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.Dropdown;

public class DropdownSelector  extends ComponentSelector<Dropdown> 
{
	private String label;

	@Override
	public List<Dropdown> filter(List<Dropdown> candidates) 
	{
		final List<Dropdown> matches = new ArrayList<>();
		
		for(Dropdown candidate : candidates)
		{
			if(label != null && label.equals(candidate.getLabel().getText()))
			{
				matches.add(candidate);
			}
		}
		
		return matches;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "select";
	}

	@Override
	public Class<Dropdown> getComponentClass() 
	{
		return Dropdown.class;
	}

	public DropdownSelector label(String label) 
	{
		this.label = label;
		return this;
	}
	
	@Override
	public String toString() 
	{
		final StringBuilder sb = new StringBuilder("Dropdown");
		
		if(label != null)
		{
			sb.append(" with label [\"" + label + "\"]");
		}
		
		return sb.toString();
	}
}
