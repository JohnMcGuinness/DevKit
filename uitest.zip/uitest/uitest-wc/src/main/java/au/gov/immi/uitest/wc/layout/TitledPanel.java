package au.gov.immi.uitest.wc.layout;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

import uitest.component.AbstractParent;
import au.gov.immi.uitest.wc.selector.TitledPanelSelector;

public class TitledPanel extends AbstractParent
{
	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}

	public String title() 
	{
		try
		{
			return getRoot().findElement(By.cssSelector("h1")).getText();
		}
		catch(NoSuchElementException e)
		{
			return "";
		}
	}

	public static TitledPanelSelector with() 
	{
		return new TitledPanelSelector();
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		
		sb.append("Titled panel");
		
		String title = title();
		
		if(title != null && title.length() > 0)
		{
			sb.append(" with title = '" + title + "'");
		}
		
		return sb.toString();
	}
}
