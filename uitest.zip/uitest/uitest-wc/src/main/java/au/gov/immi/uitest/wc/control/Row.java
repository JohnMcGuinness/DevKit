package au.gov.immi.uitest.wc.control;

import uitest.component.Component;

public class Row extends Component 
{
	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}

}
