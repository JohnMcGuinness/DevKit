package au.gov.immi.uitest.wc.selector;

import java.util.ArrayList;
import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.Label;

public class LabelSelector extends ComponentSelector<Label> 
{
	private String text;
	private String id;
	
	@Override
	public List<Label> filter(List<Label> candidates) 
	{
		final List<Label> matches = new ArrayList<>();
		
		for(Label candidate : candidates)
		{
			if(text != null && text.equals(candidate.getText()))
			{
				matches.add(candidate);
			}
		}
		
		return matches;
	}

	public LabelSelector text(final String text)
	{
		this.text = text;
		return this;
	}
	
	public LabelSelector id(final String id)
	{
		this.id = id;
		return this;
	}
	
	@Override
	public String rootElementCssSelector() 
	{
		return ".wc-label";
	}

	@Override
	public Class<Label> getComponentClass() 
	{
		return Label.class;
	}
}
