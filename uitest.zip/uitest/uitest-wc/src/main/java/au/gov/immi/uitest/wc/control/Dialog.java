package au.gov.immi.uitest.wc.control;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

import uitest.component.Parent;
import au.gov.immi.uitest.wc.selector.DialogSelector;

public class Dialog extends Parent 
{
	public String title() 
	{
		try
		{
			return getRoot().findElement(By.cssSelector("header > h1")).getText();
		}
		catch(NoSuchElementException e)
		{
			return "";
		}
	}
	
	public static DialogSelector with() 
	{
		return new DialogSelector();
	}
}
