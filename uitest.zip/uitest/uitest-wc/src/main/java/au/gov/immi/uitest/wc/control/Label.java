package au.gov.immi.uitest.wc.control;

import uitest.component.Component;
import au.gov.immi.uitest.wc.selector.LabelForSelector;
import au.gov.immi.uitest.wc.selector.LabelSelector;

public class Label extends Component 
{
	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}

	public String getText() 
	{
		return getRoot().getText();
	}
	
	public static LabelSelector with()
	{
		return new LabelSelector();
	}
	
	public static LabelForSelector forComponent(final String id)
	{
		return new LabelForSelector(id);
	}
	
        public String forId() {
            return getRoot().getAttribute("for").replace("_input", "");
        }
        
	public String id()
	{
		return getRoot().getAttribute("id");
	}
}
