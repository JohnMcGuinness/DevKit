package au.gov.immi.uitest.wc.selector;

import java.util.ArrayList;
import java.util.List;

import uitest.core.ComponentSelector;
import au.gov.immi.uitest.wc.control.Button;

public class ButtonSelector extends ComponentSelector<Button>
{
	private String text;
	private String id;
	
	@Override
	public List<Button> filter(List<Button> candidates) 
	{
		final List<Button> matches = new ArrayList<>();
		
		for(Button candidate : candidates)
		{
			if(text != null && text.equals(candidate.getText()))
			{
				matches.add(candidate);
			}
			
			if(id != null && id.equals(candidate.getId()))
			{
				matches.add(candidate);
			}
		}
		
		return matches;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "button";
	}

	@Override
	public Class<Button> getComponentClass() 
	{
		return Button.class;
	}

	public ButtonSelector text(String text) 
	{
		this.text = text;
		this.id = null;
		return this;
	}
	
	public ButtonSelector id(String id) 
	{
		this.id = id;
		this.text = null;
		return this;
	}
	
	@Override
	public String toString() 
	{
		final StringBuilder sb = new StringBuilder("Button");
		
		if(this.text != null)
		{
			sb.append(" with text [\"" + text + "\"]");
		}
		
		if(this.id != null)
		{
			sb.append(" with id [\"" + id + "\"]");
		}
		
		return sb.toString();
	}
}
