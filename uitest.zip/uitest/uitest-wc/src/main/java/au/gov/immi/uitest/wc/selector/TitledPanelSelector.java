package au.gov.immi.uitest.wc.selector;

import java.util.ArrayList;
import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.layout.TitledPanel;

public class TitledPanelSelector extends ComponentSelector<TitledPanel>
{
	private String title;

	public TitledPanelSelector title(final String title)
	{
		this.title = title;
		return this;
	}
	
	@Override
	public List<TitledPanel> filter(List<TitledPanel> list) 
	{
		final List<TitledPanel> matches = new ArrayList<>();
		
		for(TitledPanel panel : list)
		{
			if(panel.title().equals(title))
			{
				matches.add(panel);
			}
		}
		
		return matches;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "section.chrome";
	}

	@Override
	public Class<TitledPanel> getComponentClass() 
	{
		return TitledPanel.class;
	}
	
	@Override
	public String toString() 
	{
		final StringBuilder sb = new StringBuilder("Titled panel");
		
		if(title != null)
		{
			sb.append(" with title [\"" + title + "\"]");
		}
		
		return sb.toString();
	}
}
