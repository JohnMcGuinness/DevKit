package au.gov.immi.uitest.wc.control;

import uitest.component.Component;
import au.gov.immi.uitest.wc.selector.ButtonSelector;

public class Button extends Component 
{
	@Override
	public boolean isDisplayed() 
	{
		return false;
	}

	public static ButtonSelector with()
	{
		return new ButtonSelector();
	}
	
	public String getText()
	{
		return getRoot().getText();
	}
	
	public void click()
	{
		getRoot().click();
	}

	public String getId() 
	{
		return getRoot().getAttribute("id");
	}
}
