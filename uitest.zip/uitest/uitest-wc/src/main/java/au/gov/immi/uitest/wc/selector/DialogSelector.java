package au.gov.immi.uitest.wc.selector;

import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.Dialog;

public class DialogSelector extends ComponentSelector<Dialog>
{
	private String title;

	@Override
	public List<Dialog> filter(List<Dialog> list) 
	{
		return list;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "dialog";
	}

	public DialogSelector title(final String title)
	{
		this.title = title;
		return this;
	}
	
	@Override
	public Class<Dialog> getComponentClass() 
	{
		return Dialog.class;
	}

	@Override
	public String toString() 
	{
		final StringBuilder sb = new StringBuilder("Dialog");
		
		if(this.title != null)
		{
			sb.append(" with title [\"" + title + "\"]");
		}
		
		return sb.toString();
	}
}
