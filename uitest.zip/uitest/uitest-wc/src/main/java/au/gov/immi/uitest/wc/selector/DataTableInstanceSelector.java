package au.gov.immi.uitest.wc.selector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import uitest.core.ComponentSelector;
import au.gov.immi.uitest.wc.control.DataTable;

public class DataTableInstanceSelector extends ComponentSelector<DataTable> 
{
	private final int index;
	
	public DataTableInstanceSelector(final int index)
	{
		this.index = index;
	}
	
	@Override
	public List<DataTable> filter(List<DataTable> candidates)
	{
		if(!candidates.isEmpty())
		{
			return new ArrayList<DataTable>(Arrays.asList(candidates.get(index)));
		}
		else
		{
			throw new RuntimeException("No tables.");
		}
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "div[class=\"wc_wdt_cont\"]";
	}

	@Override
	public Class<DataTable> getComponentClass() 
	{
		return DataTable.class;
	}

}
