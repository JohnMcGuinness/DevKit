package au.gov.immi.uitest.wc.control;

import java.util.List;

import uitest.component.AbstractParent;
import au.gov.immi.uitest.wc.selector.MenuSelector;

public class Menu extends AbstractParent 
{
	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}
	
	public static MenuSelector controlledBy(MenuItem menuItem)
	{
//		menuItem.get
		return new MenuSelector(null);
	}
	
	public List<MenuItem> getMenuItems()
	{
		return findAll(MenuItem.instances());
	}
	
	public static MenuSelector forMenuItem(final MenuItem menuItem)
	{
		
		return new MenuSelector("");
	}
}
