package au.gov.immi.uitest.wc.control;

import java.util.List;
import java.util.logging.Logger;

import uitest.component.Component;
import uitest.component.Parent;
import uitest.core.ComponentSearchContext;
import au.gov.immi.uitest.wc.selector.RadioButtonGroupSelector;

public class RadioButtonGroup extends Component 
{
	final private Logger log = Logger.getLogger(getClass().getName());
	
	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}
	
	public static RadioButtonGroupSelector with() 
	{
		return new RadioButtonGroupSelector();
	}

	public Label getLabel()
	{
		final ComponentSearchContext context = getContext();
		final String id = getRoot().getAttribute("id");
		
//		log.info(context == null ?  "context is null" : "context is not null");
		
		return context.find(Label.forComponent(id));
	}

	public void select(String option) 
	{
		final List<RadioButton> radioButtons = Parent.fromComponent(this).findAll(RadioButton.with().label(option));
		
		for(RadioButton radioButton : radioButtons)
		{
			if(option.equalsIgnoreCase(radioButton.getLabel().getText()))
			{
				radioButton.click();
				break;
			}	
		}
	}
}
