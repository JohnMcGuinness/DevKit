package au.gov.immi.uitest.wc.control;

import java.util.logging.Logger;

import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import uitest.component.Component;
import uitest.core.ComponentSearchContext;
import au.gov.immi.uitest.wc.selector.DateFieldSelector;

public class DateField extends Component 
{
	final private Logger log = Logger.getLogger(getClass().getName());

	final private DateTimeFormatter formatter = DateTimeFormat.forPattern("dd MMM YYYY");
	
	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}

	public static DateFieldSelector with() 
	{
		return new DateFieldSelector();
	}

	public void enter(LocalDate date) 
	{
		getRoot().clear();
		getRoot().sendKeys(date.toString(formatter));
	}
	
	public LocalDate getDate()
	{
		return null;
	}
	
	public Label getLabel()
	{
		final ComponentSearchContext context = getContext();
		final String id = getRoot().getAttribute("id");
		
//		log.info(context == null ?  "context is null" : "context is not null");
		
		return context.find(Label.forComponent(id));
	}
}
