package au.gov.immi.uitest.wc.control;

import java.util.logging.Logger;

import uitest.component.Component;
import uitest.core.ComponentSearchContext;
import au.gov.immi.uitest.wc.selector.CheckBoxSelector;

public class CheckBox extends Component
{
	final private Logger log = Logger.getLogger(getClass().getName());

	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}

	public static CheckBoxSelector with() 
	{
		return new CheckBoxSelector();
	}
	
	public Label getLabel()
	{
		final ComponentSearchContext context = getContext();
		final String id = getRoot().getAttribute("id");
		
		return context.find(Label.forComponent(id));
	}

	public boolean isChecked()
	{
//		String isChecked = getRoot().getAttribute("checked");
		return "true".equalsIgnoreCase(getRoot().getAttribute("checked")) ? true : false;
	}
	
	public void check(boolean check) 
	{
		if(check && !isChecked())
		{
			getRoot().click();
		}
	}
}
