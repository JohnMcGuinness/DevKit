package au.gov.immi.uitest.wc.selector;

import java.util.ArrayList;
import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.MenuBar;

public class MenuBarSelector extends ComponentSelector<MenuBar>
{
	private List<String> items = new ArrayList<>();
	
	@Override
	public List<MenuBar> filter(List<MenuBar> list) 
	{
		return null;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "nav[role=\"menubar\"]";
	}

	@Override
	public Class<MenuBar> getComponentClass() 
	{
		return MenuBar.class;
	}

}
