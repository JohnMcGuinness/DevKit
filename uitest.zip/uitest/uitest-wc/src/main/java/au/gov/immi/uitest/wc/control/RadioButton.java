package au.gov.immi.uitest.wc.control;

import java.util.logging.Logger;

import uitest.component.Component;
import uitest.core.ComponentSearchContext;
import au.gov.immi.uitest.wc.selector.RadioButtonSelector;

public class RadioButton extends Component
{
	final private Logger log = Logger.getLogger(getClass().getName());

	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}

	public static RadioButtonSelector with() 
	{
		return new RadioButtonSelector();
	}
	
	public void click()
	{
		getRoot().click();
	}
	
	public Label getLabel()
	{
		final ComponentSearchContext context = getContext();
		final String id = getRoot().getAttribute("id");
		
//		log.info(context == null ?  "context is null" : "context is not null");
		
		return context.find(Label.forComponent(id));
	}
}
