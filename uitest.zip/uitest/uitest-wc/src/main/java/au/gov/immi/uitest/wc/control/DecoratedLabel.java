package au.gov.immi.uitest.wc.control;

import java.util.List;

import uitest.component.Component;
import uitest.component.Parent;
import uitest.core.ComponentSelector;
import au.gov.immi.uitest.wc.selector.DecoratedLabelSelecor;

public class DecoratedLabel extends Component 
{
	@Override
	public boolean isDisplayed() 
	{
		return false;
	}
	
	public Cell getBodyCell()
	{
		return Parent.fromComponent(this).find(body());
	}
	
	public Cell getHeadCell()
	{
		return Parent.fromComponent(this).find(head());
	}

	public Cell getTailCell()
	{
		return Parent.fromComponent(this).find(tail());
	}
	
	private DecoratedLabelBodySelector body()
	{
		return new DecoratedLabelBodySelector();
	}
	
	private DecoratedLabelHeadSelector head()
	{
		return new DecoratedLabelHeadSelector();
	}
	
	private DecoratedLabelTailSelector tail()
	{
		return new DecoratedLabelTailSelector();
	}
	
	private static class DecoratedLabelBodySelector extends ComponentSelector<Cell>
	{
		@Override
		public List<Cell> filter(List<Cell> list) 
		{
			return list;
		}

		@Override
		public String rootElementCssSelector() 
		{
			return "wc_wdl_b";
		}

		@Override
		public Class<Cell> getComponentClass() 
		{
			return Cell.class;
		}
	}
	
	private static class DecoratedLabelHeadSelector extends ComponentSelector<Cell>
	{
		@Override
		public List<Cell> filter(List<Cell> list) 
		{
			return list;
		}

		@Override
		public String rootElementCssSelector() 
		{
			return "wc_wdl_h";
		}

		@Override
		public Class<Cell> getComponentClass() 
		{
			return Cell.class;
		}
	}
	
	private static class DecoratedLabelTailSelector extends ComponentSelector<Cell>
	{
		@Override
		public List<Cell> filter(List<Cell> list) 
		{
			return list;
		}

		@Override
		public String rootElementCssSelector() 
		{
			return "wc_wdl_t";
		}

		@Override
		public Class<Cell> getComponentClass() 
		{
			return Cell.class;
		}
	}

	public static DecoratedLabelSelecor instance() 
	{
		return new DecoratedLabelSelecor();
	}
}
