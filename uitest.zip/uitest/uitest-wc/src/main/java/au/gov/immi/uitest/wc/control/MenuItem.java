package au.gov.immi.uitest.wc.control;

import org.openqa.selenium.By;

import uitest.component.Component;
import uitest.core.UITestException;
import au.gov.immi.uitest.wc.selector.MenuItemSelector;

public class MenuItem extends Component
{
	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}
	
	public boolean hasSubMenu()
	{
		return getRoot().getAttribute("aria-expanded") != null;
	}
	
	public boolean isExpanded()
	{
		final String expanded = getRoot().getAttribute("aria-expanded");
		
		return expanded == null ? false : Boolean.parseBoolean(expanded);
	}
	
	public void click()
	{
		if(hasSubMenu())
		{
			getRoot().findElement(By.tagName("button")).click();
		}
		else
		{
			getRoot().click();
		}
	}
	
	public Menu getSubMenu()
	{
		if(!hasSubMenu())
		{
			throw new UITestException("MenuItem does not have a menu to get");
		}
		
		if(!isExpanded())
		{
			click();
		}
		
		return getContext().find(Menu.forMenuItem(this));
	}

	public static MenuItemSelector instances() 
	{
		return new MenuItemSelector();
	}

	public String label() 
	{
		return null;
	}
}
