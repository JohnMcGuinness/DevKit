package au.gov.immi.uitest.wc.selector;

import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.DecoratedLabel;

public class DecoratedLabelSelecor extends ComponentSelector<DecoratedLabel> 
{
	@Override
	public List<DecoratedLabel> filter(List<DecoratedLabel> list) 
	{
		return list;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "wc_wdl";
	}

	@Override
	public Class<DecoratedLabel> getComponentClass() 
	{
		return 	DecoratedLabel.class;
	}
}
