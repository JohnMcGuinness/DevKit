package au.gov.immi.uitest.wc.selector;

import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.Cell;

public class TableRowCellSelector extends ComponentSelector<Cell> 
{
	@Override
	public List<Cell> filter(List<Cell> list) 
	{
		return list;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "td";
	}

	@Override
	public Class<Cell> getComponentClass() 
	{
		return Cell.class;
	}

}
