package au.gov.immi.uitest.wc.selector;

import java.util.ArrayList;
import java.util.List;

import uitest.core.ComponentSelector;

import au.gov.immi.uitest.wc.control.RadioButtonGroup;

public class RadioButtonGroupSelector extends ComponentSelector<RadioButtonGroup>  
{
	private String label;
	
	@Override
	public List<RadioButtonGroup> filter(List<RadioButtonGroup> candidates) 
	{
		final List<RadioButtonGroup> matches = new ArrayList<>();
		
		for(RadioButtonGroup candidate : candidates)
		{
			if(label != null && label.equals(candidate.getLabel().getText()))
			{
				matches.add(candidate);
			}
		}
		
		return matches;
	}

	@Override
	public String rootElementCssSelector() 
	{
		return "fieldset[class~=wc_rbg]";
	}

	@Override
	public Class<RadioButtonGroup> getComponentClass() 
	{
		return RadioButtonGroup.class;
	}

	public RadioButtonGroupSelector label(String label) 
	{
		this.label = label;
		return this;
	}
	
	@Override
	public String toString() 
	{
		final StringBuilder sb = new StringBuilder("Radio button group");
		
		if(label != null)
		{
			sb.append(" with label [\"" + label + "\"]");
		}
		
		return sb.toString();
	}
}
