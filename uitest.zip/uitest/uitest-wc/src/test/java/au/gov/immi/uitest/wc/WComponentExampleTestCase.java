package au.gov.immi.uitest.wc;

import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import uitest.core.browser.Browser;
import uitest.core.browser.ChromeBrowser;

/**
 *
 * @author exbsjv
 */
public abstract class WComponentExampleTestCase {
    
    private final Browser browser = new ChromeBrowser();

    private final static String url = "http://localhost:59326/app";
    
    @Before
    public void setup() {
        browser.open(url);
        
        WebElement qualifiedName = browser.getDriver().findElement(By.xpath("//input[@title='Enter the qualified name of an example.']"));
        
        qualifiedName.sendKeys(getQualifiedExampleClassName());
        qualifiedName.submit();
    }
    
    protected Browser getBrowser() {
        return this.browser;
    }
    
    public abstract String getQualifiedExampleClassName();
}
