package au.gov.immi.uitest.wc.control;

import au.gov.immi.uitest.wc.WComponentExampleTestCase;
import java.util.Optional;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Test;

public class WTextFieldExampleTestCase extends WComponentExampleTestCase {

    @Override
    public String getQualifiedExampleClassName() {
        return "com.github.bordertech.wcomponents.examples.TextFieldExample";
    }
    
    @Test
    public void textfieldMaxlength() {
        
        TextField tf = getBrowser().find(TextField.with().id("eg_0c1a1"));
        
        assertNotNull(tf);
        assertEquals(Optional.of(6), tf.maxLength());
    }
}
