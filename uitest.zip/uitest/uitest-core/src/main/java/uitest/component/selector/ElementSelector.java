package uitest.component.selector;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import uitest.component.ElementComponent;
import uitest.core.ComponentSelector;

public class ElementSelector extends ComponentSelector<ElementComponent>
{
	private final Map<String, String> attributes = new HashMap<>();
	private String tag;
	
	@Override
	public List<ElementComponent> filter(List<ElementComponent> list) 
	{
		return list;
	}
	
	public Class<ElementComponent> getComponentClass()
	{
		return ElementComponent.class;
	}
	
	public String rootElementCssSelector()
	{
		final StringBuilder sb = new StringBuilder(tag == null ? "*" : tag);
		
		for(Map.Entry<String, String> entry : attributes.entrySet())
		{
			sb.append(attributeStringBuilder(entry.getKey(), entry.getValue()));
		}
		
		return sb.toString();
	}
	
	private String attributeStringBuilder(final String name, final String value)
	{
		final StringBuilder sb = new StringBuilder();
		
		sb.append("[").append(name).append("=").append(value).append("]");
		
		return sb.toString();
	}
	
	public ElementSelector tag(final String tag)
	{
		this.tag = tag;
		return this;
	}
	
	public ElementSelector id(final String id)
	{
		attributes.put("id", id);
		return this;
	}
	
	public ElementSelector name(final String name)
	{
		attributes.put("name", name);
		return this;
	}
	
	public ElementSelector attribute(final String name, final String value)
	{
		attributes.put(name, value);
		return this;
	}
}
