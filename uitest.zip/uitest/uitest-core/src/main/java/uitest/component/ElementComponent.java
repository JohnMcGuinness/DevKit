package uitest.component;

import uitest.component.selector.ElementSelector;

public class ElementComponent extends Component 
{
	public static ElementSelector with()
	{
		return new ElementSelector();
	}
	
	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}
	
	public void click()
	{
		getRoot().click();
	}
	
	public boolean getBooleanAttribute(final String attribute)
	{
		final String attributeValue = getRoot().getAttribute(attribute);
		
		System.out.println("getBooleanAttribute(" + attribute + ") = " + attributeValue);
		
		return "true".equalsIgnoreCase(attributeValue) ? true : false;
	}
}
