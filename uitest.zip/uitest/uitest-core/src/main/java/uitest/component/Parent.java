package uitest.component;

public class Parent extends AbstractParent 
{
	public Parent(){}
	
	@Override
	public boolean isDisplayed() 
	{
		return getRoot().isDisplayed();
	}
	
	public static Parent fromComponent(final Component component)
	{
		return ComponentUtils.asParent(component);
	}
}
