package uitest.component;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

import uitest.core.ComponentSearchContext;
import org.openqa.selenium.WebElement;

class ComponentUtils 
{
	private ComponentUtils(){}
	
	static <D extends Component> Parent asParent(final D component)
	{
		if(Component.class.isAssignableFrom(component.getClass()))
		{
			return createComponent(Parent.class, component.getRoot(), component.getContext());
		}
		
		return null;
	}
	
	protected static <C extends Component> C createComponent(Class<C> componentClass, WebElement root, ComponentSearchContext context)
	{
		C component = newComponentInstance(componentClass);
		
		Field rootField = findComponentField(componentClass, "root");
		Field contextField = findComponentField(componentClass, "context");
		
		setField(component, rootField, root);
		setField(component, contextField, context);
		
		return component;
	}
	
	protected static <C extends Component, D extends Component> C createEnclosedComponent(D enclosingComponentInstance, Class<C> componentClass, WebElement root, ComponentSearchContext context)
	{
		C component = newEnclosedComponentInstance(enclosingComponentInstance,componentClass);
		
		Field rootField = findComponentField(componentClass, "root");
		Field contextField = findComponentField(componentClass, "context");
		
		setField(component, rootField, root);
		setField(component, contextField, context);
		
		return component;
	}
	
	private static <C extends Component> void setField(final C component, final Field rootField, final Object root)
	{
		try 
		{
			rootField.setAccessible(true);
			rootField.set(component, root);
			rootField.setAccessible(false);
		}
		catch (IllegalArgumentException | IllegalAccessException e) 
		{
			throw new RuntimeException(e);
		}
	}
	
	private static <C extends Component> Field findComponentField(final Class<C> componentClass, final String fieldName)
	{
		Class<? super C> clazz = componentClass;
		Field field = null;
		
		while(field == null && clazz != null)
		{
			try
			{
				field = clazz.getDeclaredField(fieldName);
			}
			catch(NoSuchFieldException nsfe)
			{
				clazz = clazz.getSuperclass();
				continue;
			}
			 
			return field;
		}
		
		return null;
	}
	
	private static <C extends Component> C newComponentInstance(final Class<C> componentClass)
	{
		try 
		{
			Constructor<C> ctor = componentClass.getDeclaredConstructor();
			return ctor.newInstance();
		}
		catch (InstantiationException | 
			   IllegalAccessException | 
			   IllegalArgumentException | 
			   InvocationTargetException e) 
		{
			throw new RuntimeException();
		} 
		catch (NoSuchMethodException e) 
		{
			throw new RuntimeException(e);
		}
		catch (SecurityException e) 
		{
			throw new RuntimeException();
		}
	}
	
	private static <C extends Component, D extends Component> C newEnclosedComponentInstance(final D enclosingComponentInstance,  final Class<C> componentClass)
	{
		try 
		{
			Constructor<C> ctor = componentClass.getDeclaredConstructor(enclosingComponentInstance.getClass());
			ctor.setAccessible(true);
			return ctor.newInstance(enclosingComponentInstance);
		}
		catch (InstantiationException | 
			   IllegalAccessException | 
			   IllegalArgumentException | 
			   InvocationTargetException e) 
		{
			throw new RuntimeException(e);
		} 
		catch (NoSuchMethodException e) 
		{
			throw new RuntimeException(e);
		}
		catch (SecurityException e) 
		{
			throw new RuntimeException(e);
		}
	}
	
	public String getRootAttribute(final String attributeName, final Component component)
	{
		return component.getRoot().getAttribute(attributeName);
	}
}
