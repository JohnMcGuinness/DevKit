package uitest.component;

import java.util.ArrayList;
import java.util.List;

import uitest.core.ComponentSearchContext;
import uitest.core.ComponentSelector;
import uitest.core.EnclosedComponentSelector;
import uitest.core.NoSuchComponentException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public abstract class AbstractParent extends Component implements ComponentSearchContext 
{
	public AbstractParent(){}
	
	@Override
	public <C extends Component, S extends ComponentSelector<C>> C find(S selector) 
	{
		final List<C> components = findAll(selector);
		
		if(components == null || components.isEmpty())
		{
			throw new NoSuchComponentException("selector did not find any components: " + selector);
		}
		
		return components.get(0);
	}

	@Override
	public <C extends Component, S extends ComponentSelector<C>> List<C> findAll(S selector) 
	{
		final List<C> components = findComponents(selector);
		
		return selector.filter(components);
	}
	
	private <C extends Component, S extends ComponentSelector<C>> List<C> findComponents(S selector) 
	{
		final List<WebElement> roots =  getRoot().findElements(By.cssSelector(selector.rootElementCssSelector()));

		List<C> components = new ArrayList<>();

		for(WebElement root : roots)
		{
			C component = null; 
					
			if(selector instanceof EnclosedComponentSelector<?, ?>)
			{
				Component enclosingComponent = ((EnclosedComponentSelector<?, ?>) selector).getEnclosingComponent();
				component = ComponentUtils.createEnclosedComponent(enclosingComponent, selector.getComponentClass(), root, this);
			}
			else
			{
				component = ComponentUtils.createComponent(selector.getComponentClass(), root, this);
			}
			
			components.add(component);
		}

		return components;
	}
}
