package uitest.component;

public interface CanBeReadOnly extends UIComponent
{
	public boolean isReadOnly();
}
