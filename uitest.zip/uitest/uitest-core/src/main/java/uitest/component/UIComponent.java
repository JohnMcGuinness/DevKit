package uitest.component;

public interface UIComponent 
{}
