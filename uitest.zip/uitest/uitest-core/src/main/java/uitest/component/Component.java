package uitest.component;

import uitest.core.ComponentSearchContext;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.internal.WrapsDriver;

public abstract class Component implements UIComponent
{
    /**The WebElement that is the root of this Component.*/
    private WebElement root;

    /**The ComponentSearchContext within which this component, if it exists, can be found.*/
    private ComponentSearchContext context;
    
    protected WebElement getRoot()
    {
    	return root;
    }
    
    public final ComponentSearchContext getContext()
    {
    	return context;
    }
    
    protected String getAttributeOfRootNamed(final String attributeName)
    {
    	WebDriver driver = ((WrapsDriver) getRoot()).getWrappedDriver();
    	
//    	System.out.println("Attribute: " + attributeName + ", Tag: " +  getRoot().getTagName());
    	System.out.println("Outer html: " + (String)((JavascriptExecutor)driver).executeScript("return arguments[0].outerHTML;", getRoot()));
    	return getRoot().getAttribute(attributeName.toLowerCase());
    }
    
    public abstract boolean isDisplayed();
}
