package uitest.datatools;

public class DataGenerator 
{
	public static String randomString(final int length)
	{
		final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		
		final StringBuilder builder = new StringBuilder();
		
		for(int count = 0; count < length; count++)
		{
			int i = (int)(Math.random() * chars.length());
			
			builder.append(chars.substring(i, i + 1));
		}
		
		return builder.toString();
	}
}
