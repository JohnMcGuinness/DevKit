package uitest.core;

public class UITestException extends RuntimeException 
{
    /** */
	private static final long serialVersionUID = 5511217970298302715L;

	public UITestException() 
    {
        super();
    }
    
    public UITestException(String message) 
    {
        super(message);
    }
    
    public UITestException(String message, Throwable cause) 
    {
        super(message, cause);
    }
    
    public UITestException(Throwable cause) 
    {
        super(cause);
    }
}
