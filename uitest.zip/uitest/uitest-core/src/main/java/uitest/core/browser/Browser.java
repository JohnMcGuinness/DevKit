package uitest.core.browser;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import uitest.component.Component;
import uitest.core.ComponentSearchContext;
import uitest.core.ComponentSelector;
import uitest.core.NoSuchComponentException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Browser implements ComponentSearchContext {

    private WebDriver driver;

    public Browser() {
    }

    protected Browser(WebDriver driver) {
        this.driver = driver;
    }

    @Override
    public <C extends Component, S extends ComponentSelector<C>> C find(S selector) {
        final List<C> components = findAll(selector);

        if (components == null || components.isEmpty()) {
            throw new NoSuchComponentException("selector did not find any components: " + selector);
        }

        return components.get(0);
    }

    @Override
    public <C extends Component, S extends ComponentSelector<C>> List<C> findAll(S selector) {
        final List<C> components = findComponents(selector);

        return selector.filter(components);
    }

    protected void setDriver(WebDriver driver) {
        this.driver = driver;
    }

    public void open(String url) {
        driver.get(url);
    }

    public void close() {
        driver.quit();
    }

    public String getCurrentUrl() {
        URL url = null;

        try {
            url = new URL(driver.getCurrentUrl());
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }

        return url.getHost();
    }

    private <C extends Component, S extends ComponentSelector<C>> List<C> findComponents(S selector) {
        final List<WebElement> roots = driver.findElements(By.cssSelector(selector.rootElementCssSelector()));

        List<C> components = new ArrayList<>();

        Field rootField = findComponentField(selector.getComponentClass(), "root");
        Field contextField = findComponentField(selector.getComponentClass(), "context");

        for (WebElement root : roots) {
            C component = newComponentInstance(selector.getComponentClass());

            setField(component, rootField, root);
            setField(component, contextField, this);

            components.add(component);
        }

        return components;
    }

//	private <C extends Component> Field findRootField(final Class<C> componentClass)
//	{
//		Class<? super C> clazz = componentClass;
//		Field rootField = null;
//		
//		while(rootField == null && clazz != null)
//		{
//			try
//			{
//				rootField = clazz.getDeclaredField("root");
//			}
//			catch(NoSuchFieldException nsfe)
//			{
//				clazz = clazz.getSuperclass();
//				continue;
//			}
//			 
//			return rootField;
//		}
//		
//		return null;
//	}
    private <C extends Component> Field findComponentField(final Class<C> componentClass, final String fieldName) {
        Class<? super C> clazz = componentClass;
        Field rootField = null;

        while (rootField == null && clazz != null) {
            try {
                rootField = clazz.getDeclaredField(fieldName);
            } catch (NoSuchFieldException nsfe) {
                clazz = clazz.getSuperclass();
                continue;
            }

            return rootField;
        }

        return null;
    }

    private <C extends Component> C newComponentInstance(final Class<C> componentClass) {

        try {
            Constructor<C> ctor = componentClass.getDeclaredConstructor();
            return ctor.newInstance();
        } catch (InstantiationException
            | IllegalAccessException
            | IllegalArgumentException
            | InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        }
    }

    private <C extends Component> void setField(final C component, final Field rootField, final Object root) {
        try {
            rootField.setAccessible(true);
            rootField.set(component, root);
            rootField.setAccessible(false);
        } catch (IllegalArgumentException | IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public void getAcceptAlert() {
        driver.switchTo().alert().accept();
    }

    public Object executeScript(final String script) {
        return ((JavascriptExecutor) driver).executeScript(script);
    }
    
    public WebDriver getDriver() {
        return this.driver;
    }
}
