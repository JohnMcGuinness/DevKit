package uitest.core;

import java.util.HashMap;
import java.util.Map;

public enum Environment 
{
	E1("E1"), E3("E3"), E4("E4"), E5("E5"), 
	E6("E6"), E7("E7");
	
	private static Map<String, Environment> MAP = new HashMap<String, Environment>();
	
	static
	{
		MAP.put(E1.code, E1);
		MAP.put(E3.code, E3);
		MAP.put(E4.code, E4);
		MAP.put(E5.code, E5);
		MAP.put(E6.code, E6);
		MAP.put(E7.code, E7);
	}
	
	private String code;

	Environment(final String code)
	{
		this.code = code;
	}
	
	public static Environment lookup(final String env)
	{
		return env == null ? Environment.E6 : (MAP.get(env.toUpperCase()) == null ? Environment.E1 : MAP.get(env.toUpperCase()));
	}
}
