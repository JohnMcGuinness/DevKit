package uitest.core;

import java.util.List;

import uitest.component.Component;

public abstract class ComponentSelector<C extends Component>
{
	public abstract List<C> filter(List<C> list);
	
	public abstract String rootElementCssSelector();
  
	public abstract Class<C> getComponentClass();
}
