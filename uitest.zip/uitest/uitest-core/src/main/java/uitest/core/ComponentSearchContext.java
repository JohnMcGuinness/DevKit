package uitest.core;

import java.util.List;

import uitest.component.Component;

public interface ComponentSearchContext 
{
    public <C extends Component, S extends ComponentSelector<C>> C find(S selector);

    public <C extends Component, S extends ComponentSelector<C>> List<C> findAll(S selector);
}
