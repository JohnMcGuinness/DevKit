package uitest.core;

import java.util.List;

import uitest.component.Component;

public abstract class EnclosedComponentSelector<D extends Component, C extends Component> extends ComponentSelector<C>
{
	public abstract List<C> filter(List<C> list);
	
	public abstract String rootElementCssSelector();
  
	public abstract Class<C> getComponentClass();
	
	public abstract D getEnclosingComponent();
}
