package uitest.core;

import java.util.logging.Logger;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.SystemConfiguration;

public class UITestConfiguration 
{
	final Logger log = Logger.getLogger(getClass().getName());
	
	private static final long DEFAULT_TIMEOUT = 5000L;
	private static final long DEFAULT_POLLING_INTERVAL = 500L;
	
    private static UITestConfiguration instance;
    private Configuration config;
    
    private UITestConfiguration()
    {
    	this.config =  new SystemConfiguration();
    }
    
	public synchronized static UITestConfiguration getInstance()
    {
        if (instance == null)
        {
            instance = new UITestConfiguration();
        }

        return instance;
    }

	public long timeout()
	{
		final long timeout = config.getLong("uitest-timeout", DEFAULT_TIMEOUT); 
		
//		log.info("Timeout: " + timeout);
		
		return timeout;
	}
	
	public long pollingInterval()
	{
		return config.getLong("uitest.pollingInterval", DEFAULT_POLLING_INTERVAL);
	}
	
	public Environment getEnvironment()
	{
		return Environment.lookup(config.getString("uitest-env"));
	}
}
