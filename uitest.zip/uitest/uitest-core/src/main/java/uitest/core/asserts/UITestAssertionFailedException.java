package uitest.core.asserts;

public class UITestAssertionFailedException extends RuntimeException
{
	private static final long serialVersionUID = -2370734749226589244L;

	public UITestAssertionFailedException()
	{}
	
	public UITestAssertionFailedException(String message) 
	{
        super(message);
    }
	
    public UITestAssertionFailedException(String message, Throwable cause) 
    {
        super(message, cause);
    }
}
