package uitest.core.browser;

import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeBrowser extends Browser {

    static {
        System.setProperty("webdriver.chrome.driver", "C:\\Apps\\Software\\chromedriver.exe");
    }

    public ChromeBrowser() {
        super(new ChromeDriver());
    }
}
