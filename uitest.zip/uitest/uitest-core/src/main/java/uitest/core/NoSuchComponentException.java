package uitest.core;

public class NoSuchComponentException extends UITestException 
{
	/**  */
	private static final long serialVersionUID = -1145368383697107447L;

    public NoSuchComponentException() 
    {
        super();
    }
    
    public NoSuchComponentException(String message) 
    {
        super(message);
    }
    
    public NoSuchComponentException(String message, Throwable cause) 
    {
        super(message, cause);
    }
    
    public NoSuchComponentException(Throwable cause) 
    {
        super(cause);
    }
}
