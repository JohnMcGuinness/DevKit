package uitest.core;

public class Wait 
{
	private ComponentSelector<?> selector;

	private Wait(ComponentSelector<?> selector)
	{
		this.selector = selector;
	}
	
	public static Wait until(ComponentSelector<?> selector)
	{
		return new Wait(selector);
	}
	
	public void isDisplayedIn(ComponentSearchContext context)
	{
		final long start = System.currentTimeMillis();
		final long timeout = UITestConfiguration.getInstance().timeout();
		final long pollingInterval = UITestConfiguration.getInstance().pollingInterval();
		
		while ((System.currentTimeMillis() - start) < timeout)
		{
			try
			{
				context.find(selector);
				return;
			}
			catch (RuntimeException ex)
			{
				try 
				{
					Thread.sleep(pollingInterval);
				}
				catch (InterruptedException e) 
				{
					e.printStackTrace();
					break;
				}
			}
		}
		
		throw new RuntimeException("Could not find: " + selector);
//		throw new PageComponentTimeOutException();
	}
}
