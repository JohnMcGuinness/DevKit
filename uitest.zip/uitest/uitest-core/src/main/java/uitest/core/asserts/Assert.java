package uitest.core.asserts;

import uitest.component.CanBeReadOnly;
import uitest.component.Component;
import uitest.core.browser.Browser;
import uitest.core.ComponentSearchContext;
import uitest.core.ComponentSelector;
import uitest.core.Wait;

public class Assert 
{
	private final ComponentSelector<? extends Component> selector;
	private ComponentSearchContext context;

	private Assert(ComponentSelector<? extends Component> selector)
	{
		this.selector = selector;
	}
	
	public static Assert that(ComponentSelector<? extends Component> selector)
	{
		return new Assert(selector);
	}
	
	public Assert in(ComponentSearchContext context)
	{
		this.context = context;
		return this;
	}
	
	public void isReadOnly()
	{
		CanBeReadOnly component = (CanBeReadOnly) context.find(selector);
		
		if(!component.isReadOnly())
		{
			throw new UITestAssertionFailedException("Expected [" + selector + "] to be read only but it was not.");
		}
	}

	public void isDisplayedIn(ComponentSearchContext context) 
	{
		try
		{
			System.out.println("Looking for " + selector.rootElementCssSelector() + " in " + context);
			Wait.until(selector).isDisplayedIn(context);
		}
		catch(RuntimeException e)
		{
			throw new UITestAssertionFailedException(selector + " was not displayed in " + context, e);
		}
	}
}
